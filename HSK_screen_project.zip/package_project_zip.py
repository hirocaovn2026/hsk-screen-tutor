# -*- coding: utf-8 -*-
import zipfile
import os

output_zip = "HSK_screen_project.zip"
exclude_dirs = {".git", ".gradle", "build", ".idea", "__pycache__"}
exclude_files = {output_zip}

print("Đang nén dự án để đưa lên GitHub Actions...")
with zipfile.ZipFile(output_zip, "w", zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk("."):
        # Filter directories in-place
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        for file in files:
            if file in exclude_files or file.endswith(".pyc"):
                continue
            file_path = os.path.join(root, file)
            arcname = os.path.relpath(file_path, ".")
            zipf.write(file_path, arcname)

print(f"Đã tạo thành công file nén: {output_zip} ({os.path.getsize(output_zip) // 1024} KB)")
