# -*- coding: utf-8 -*-
import json

words = json.load(open('app/src/main/assets/hsk_words.json', 'r', encoding='utf-8'))
targets = ['菜', '吃', '喝', '茶', '电脑', '北京', '帮助', '高兴', '便宜', '休息', '考试', '准备', '爱', '医生']
for w in words:
    if w['hanzi'] in targets:
        print(f"[{w['level']}] {w['hanzi']} ({w['pinyin']}):\n    {w['breakdown']}\n")
