import os
import json

# Let's inspect the files in web_preview
print("Current files:", os.listdir("web_preview"))
