# HSK Screen Tutor - Ứng dụng Học Từ Vựng Tiếng Trung Qua Màn Hình Khóa Android

Ứng dụng hỗ trợ học từ vựng tiếng Trung (HSK 1 đến HSK 5) tự động xuất hiện mỗi khi bạn **mở khóa điện thoại** hoặc **theo chu kỳ hẹn giờ mặc định**. Ứng dụng áp dụng phương pháp **Lặp lại ngắt quãng (Spaced Repetition System - SRS)** chuẩn khoa học, tích hợp khung **luyện viết tay chữ Hán ô lớn** (田字格 260px) và phát âm chuẩn bản xứ.

---

## 🌟 Tính Năng Nổi Bật

1. **Kho từ vựng HSK 1 - 5 phong phú (652 từ vựng chuẩn)**:
   - **HSK 1**: 148 từ (Trọn bộ cấp độ 1 cơ bản)
   - **HSK 2**: 152 từ (Trọn bộ cấp độ 2)
   - **HSK 3**: 147 từ (Từ vựng giao tiếp thực tế)
   - **HSK 4**: 125 từ (Từ vựng chuyên sâu & công việc)
   - **HSK 5**: 80 từ (Từ vựng nâng cao & học thuật)
   - Mỗi từ đều có: Chữ Hán, Phiên âm Pinyin có dấu, Định nghĩa tiếng Anh, Phân loại từ, **Câu ví dụ thực tế** kèm Pinyin và dịch nghĩa tiếng Anh.

2. **Khung luyện viết chữ Hán cỡ lớn (260px × 260px)**:
   - Khung vẽ tay ô chữ Điền/Mễ (田字格) rộng rãi, nét mực bút lông chân thực.
   - **Hỗ trợ từ ghép nhiều chữ (như 爸爸, 出租车, 对不起...)**: Có thanh chọn từng chữ `[Chữ 1: 爸]` `[Chữ 2: 爸]` và nút `Chữ tiếp ❯` để luyện từng chữ riêng biệt chuẩn xác không bị đè nét.
   - Nút bật/tắt **Nét mẫu mờ** (Ghost guide) và nút **Xóa nét** nhanh.

3. **Nhắc nhở khi mở khóa màn hình (`Unlock Trigger`)**:
   - Khi bạn mở khóa điện thoại, 01 thẻ từ vựng sẽ xuất hiện để bạn xem, nghe phát âm, viết lại và đọc câu ví dụ.
   - Tích hợp bộ đệm **Thời gian chờ chống làm phiền (`Cooldown`)** (mặc định 3 phút) để tránh hiện liên tục khi bạn bật tắt màn hình nhiều lần.

4. **Hẹn giờ định kỳ (`Periodic Interval Timer`)**:
   - Tự động nhắc nhở sau mỗi khoảng thời gian mặc định (15 phút, 30 phút, 1 giờ...) để củng cố phản xạ.

5. **Kế hoạch 7 từ vựng / ngày & Chu kỳ SRS (Ngày 1, 3, 5, 10)**:
   - **Ngày 1**: Hệ thống phân bổ 7 từ mới theo cấp độ HSK bạn chọn. Các từ này lặp lại liên tục trong ngày qua mỗi lần mở máy/hẹn giờ.
   - **Ngày 3**: Tự động đưa các từ của Ngày 1 vào danh sách ôn tập đợt 1.
   - **Ngày 5**: Tự động nhắc lại ôn tập đợt 2.
   - **Ngày 10**: Nhắc lại ôn tập lần cuối trước khi đưa vào nhóm **Đã thuộc vĩnh viễn (Mastered)**.

6. **Phát âm chuẩn tiếng Trung (Text-to-Speech)**:
   - Tự động phát âm hoặc chạm vào biểu tượng loa để nghe phát âm chuẩn bản xứ cho cả từ vựng và câu ví dụ.

---

## 📁 Cấu Trúc Mã Nguồn

```
HSK_screen/
├── app/
│   ├── src/main/
│   │   ├── AndroidManifest.xml          # Khai báo quyền, Service nền và Activities
│   │   ├── assets/
│   │   │   └── hsk_words.json           # 652 từ vựng HSK 1-5 có Pinyin & Ví dụ
│   │   ├── java/com/hsk/screentutor/
│   │   │   ├── HskApplication.kt        # Khởi tạo DB Room & SrsManager
│   │   │   ├── data/                    # Model, Room Database, DAO, Repository
│   │   │   ├── srs/
│   │   │   │   └── SrsManager.kt        # Thuật toán SRS 7 từ/ngày, chu kỳ 1-3-5-10
│   │   │   ├── service/
│   │   │   │   ├── VocabularyForegroundService.kt # Dịch vụ nền & bắt sự kiện mở khóa
│   │   │   │   ├── IntervalAlarmReceiver.kt       # Bắt sự kiện hẹn giờ
│   │   │   │   └── BootReceiver.kt                # Tự khởi động lại khi reboot máy
│   │   │   ├── ui/
│   │   │   │   ├── MainActivity.kt      # Dashboard tiến độ, thống kê 7 từ hôm nay
│   │   │   │   ├── PopupActivity.kt     # Màn hình thẻ từ vựng hiện khi mở khóa/hẹn giờ
│   │   │   │   ├── WritingCanvasView.kt # View vẽ tay chữ Hán trên ô Điền/Mễ (260dp)
│   │   │   │   ├── SettingsActivity.kt  # Cài đặt chu kỳ, số từ/ngày, thời gian chờ
│   │   │   │   ├── WordListActivity.kt  # Tra cứu kho 652 từ vựng HSK 1-5
│   │   │   │   └── WordAdapter.kt       # Adapter hiển thị danh sách từ
│   │   │   └── util/
│   │   │       ├── SoundManager.kt      # TextToSpeech tiếng Trung
│   │   │       └── NotificationHelper.kt# Kênh thông báo và cảnh báo toàn màn hình
│   │   └── res/                         # Giao diện XML, màu sắc, icon vector
├── web_preview/
│   └── index.html                       # Trình giả lập HTML5 chạy thử ngay lập tức (652 từ)
├── build.gradle.kts
└── settings.gradle.kts
```

---

## 🚀 Cách Thử Nghiệm Ngay Lập Tức

### Cách 1: Chạy thử Trình Giả Lập Ngay Lập Tức (Web Preview)

1. Mở terminal tại thư mục này và chạy:
   ```bash
   python -m http.server 8080
   ```
2. Mở trình duyệt truy cập vào:
   ```
   http://localhost:8080/web_preview/
   ```
3. Bạn có thể chọn chuyển đổi giữa các cấp độ **HSK 1, HSK 2, HSK 3, HSK 4, HSK 5** để trải nghiệm kho từ mới.

### Cách 2: Mở & Đóng Gói File APK Qua Android Studio

1. Mở **Android Studio**, chọn **File -> Open** và chọn thư mục `E:\HSK_screen`.
2. Chờ Android Studio đồng bộ xong (Sync Project with Gradle Files).
3. Kết nối điện thoại qua USB hoặc máy ảo, bấm nút **Run ▶** để cài ứng dụng trực tiếp lên máy.
