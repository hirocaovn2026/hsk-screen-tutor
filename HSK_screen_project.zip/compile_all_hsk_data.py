# -*- coding: utf-8 -*-
import json
import os

from data_hsk2 import hsk2_data
from data_hsk3 import hsk3_data
from data_hsk4 import hsk4_data
from data_hsk4_part2 import hsk4_extra
from data_hsk5 import hsk5_data
from data_hsk5_part2 import hsk5_extra

all_words = []

# Load HSK 1 from original file
with open("app/src/main/assets/hsk_words.json", "r", encoding="utf-8") as f:
    orig = json.load(f)
    for w in orig:
        if w["level"] == 1:
            all_words.append(w)

print(f"Loaded {len(all_words)} HSK 1 words.")

# Add HSK 2 (wid starting at 2001)
wid2 = 2001
for item in hsk2_data:
    all_words.append({
        "id": wid2,
        "level": 2,
        "hanzi": item[0],
        "pinyin": item[1],
        "english": item[2],
        "partOfSpeech": item[3],
        "exampleCn": item[4],
        "examplePinyin": item[5],
        "exampleEn": item[6]
    })
    wid2 += 1

# Add HSK 3 (wid starting at 3001)
wid3 = 3001
for item in hsk3_data:
    all_words.append({
        "id": wid3,
        "level": 3,
        "hanzi": item[0],
        "pinyin": item[1],
        "english": item[2],
        "partOfSpeech": item[3],
        "exampleCn": item[4],
        "examplePinyin": item[5],
        "exampleEn": item[6]
    })
    wid3 += 1

# Add HSK 4 (wid starting at 4001)
wid4 = 4001
for item in hsk4_data + hsk4_extra:
    all_words.append({
        "id": wid4,
        "level": 4,
        "hanzi": item[0],
        "pinyin": item[1],
        "english": item[2],
        "partOfSpeech": item[3],
        "exampleCn": item[4],
        "examplePinyin": item[5],
        "exampleEn": item[6]
    })
    wid4 += 1

# Add HSK 5 (wid starting at 5001)
wid5 = 5001
for item in hsk5_data + hsk5_extra:
    all_words.append({
        "id": wid5,
        "level": 5,
        "hanzi": item[0],
        "pinyin": item[1],
        "english": item[2],
        "partOfSpeech": item[3],
        "exampleCn": item[4],
        "examplePinyin": item[5],
        "exampleEn": item[6]
    })
    wid5 += 1

# Deduplicate by (level, hanzi) just in case
seen = set()
unique_words = []
for w in all_words:
    key = (w["level"], w["hanzi"])
    if key not in seen:
        seen.add(key)
        unique_words.append(w)

# Re-index ids cleanly
for i, w in enumerate(unique_words):
    w["id"] = 1000 + i + 1

# Write to app/src/main/assets/hsk_words.json
with open("app/src/main/assets/hsk_words.json", "w", encoding="utf-8") as f:
    json.dump(unique_words, f, ensure_ascii=False, indent=2)

print(f"Total compiled unique words: {len(unique_words)}")
from collections import Counter
counts = Counter(w['level'] for w in unique_words)
for lvl in sorted(counts.keys()):
    print(f"  HSK {lvl}: {counts[lvl]} words")
