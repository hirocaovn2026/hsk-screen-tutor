# -*- coding: utf-8 -*-
import json
import os

words = []

def add_word(wid, level, hanzi, pinyin, english, pos, ex_cn, ex_py, ex_en):
    words.append({
        "id": wid,
        "level": level,
        "hanzi": hanzi,
        "pinyin": pinyin,
        "english": english,
        "partOfSpeech": pos,
        "exampleCn": ex_cn,
        "examplePinyin": ex_py,
        "exampleEn": ex_en
    })

# HSK 1 - Complete Official 150 Core Vocabulary
hsk1_list = [
    ("爱", "ài", "to love; affection", "verb", "我爱我的家人。", "Wǒ ài wǒ de jiārén.", "I love my family."),
    ("八", "bā", "eight", "numeral", "他有八本书。", "Tā yǒu bā běn shū.", "He has eight books."),
    ("爸爸", "bàba", "father; dad", "noun", "我爸爸是医生。", "Wǒ bàba shì yīshēng.", "My dad is a doctor."),
    ("北京", "Běijīng", "Beijing (capital of China)", "noun", "我想去北京旅游。", "Wǒ xiǎng qù Běijīng lǚyóu.", "I want to visit Beijing."),
    ("杯子", "bēizi", "cup; glass", "noun", "桌上有一个杯子。", "Zhuō shàng yǒu yí ge bēizi.", "There is a cup on the table."),
    ("本", "běn", "measure word for books", "measure word", "这是一本好书。", "Zhè shì yì běn hǎo shū.", "This is a good book."),
    ("不客气", "bú kèqi", "you're welcome", "phrase", "谢谢！——不客气。", "Xièxie! —— Bú kèqi.", "Thanks! — You're welcome."),
    ("不", "bù", "not; no", "adverb", "我不是老师。", "Wǒ bú shì lǎoshī.", "I am not a teacher."),
    ("菜", "cài", "dish; cuisine; vegetable", "noun", "中国菜很好吃。", "Zhōngguó cài hěn hǎochī.", "Chinese food is delicious."),
    ("茶", "chá", "tea", "noun", "请喝茶。", "Qǐng hē chá.", "Please drink tea."),
    ("吃", "chī", "to eat", "verb", "你想吃什么？", "Nǐ xiǎng chī shénme?", "What do you want to eat?"),
    ("出租车", "chūzūchē", "taxi; cab", "noun", "我们坐出租车去。", "Wǒmen zuò chūzūchē qù.", "We go by taxi."),
    ("打电话", "dǎ diànhuà", "to make a phone call", "verb", "他在打电话。", "Tā zài dǎ diànhuà.", "He is making a phone call."),
    ("大", "dà", "big; large", "adjective", "这个苹果很大。", "Zhè ge píngguǒ hěn dà.", "This apple is very big."),
    ("的", "de", "possessive particle", "particle", "这是我的书。", "Zhè shì wǒ de shū.", "This is my book."),
    ("点", "diǎn", "o'clock; dot", "noun", "现在八点了。", "Xiànzài bā diǎn le.", "It is eight o'clock now."),
    ("电脑", "diànnǎo", "computer", "noun", "我买了一台电脑。", "Wǒ mǎi le yì tái diànnǎo.", "I bought a computer."),
    ("电视", "diànshì", "television; TV", "noun", "爸爸在看电视。", "Bàba zài kàn diànshì.", "Dad is watching TV."),
    ("电影", "diànyǐng", "movie; film", "noun", "这部电影很好看。", "Zhè bù diànyǐng hěn hǎokàn.", "This movie is great."),
    ("东西", "dōngxi", "thing; stuff", "noun", "你买了什么东西？", "Nǐ mǎi le shénme dōngxi?", "What things did you buy?"),
    ("都", "dōu", "all; both", "adverb", "我们都是好朋友。", "Wǒmen dōu shì hǎo péngyou.", "We are all good friends."),
    ("读", "dú", "to read", "verb", "请跟我一起读。", "Qǐng gēn wǒ yìqǐ dú.", "Please read along with me."),
    ("对不起", "duìbuqǐ", "sorry; excuse me", "phrase", "对不起，我迟到了。", "Duìbuqǐ, wǒ chídào le.", "Sorry, I am late."),
    ("多", "duō", "many; much", "adjective", "这里人很多。", "Zhèlǐ rén hěn duō.", "There are many people here."),
    ("多少", "duōshao", "how much; how many", "pronoun", "这个多少钱？", "Zhè ge duōshao qián?", "How much is this?"),
    ("儿子", "érzi", "son", "noun", "他儿子很聪明。", "Tā érzi hěn cōngmíng.", "His son is very clever."),
    ("二", "èr", "two", "numeral", "我有两只猫。", "Wǒ yǒu liǎng zhī māo.", "I have two cats."),
    ("饭店", "fàndiàn", "restaurant", "noun", "我们在饭店吃饭。", "Wǒmen zài fàndiàn chīfàn.", "We eat at a restaurant."),
    ("飞机", "fēijī", "airplane", "noun", "飞机起飞了。", "Fēijī qǐfēi le.", "The airplane took off."),
    ("分钟", "fēnzhōng", "minute", "noun", "请等十分钟。", "Qǐng děng shí fēnzhōng.", "Please wait ten minutes."),
    ("高兴", "gāoxìng", "happy; glad", "adjective", "很高兴认识你。", "Hěn gāoxìng rènshi nǐ.", "Nice to meet you."),
    ("个", "gè", "general measure word", "measure word", "我有一个苹果。", "Wǒ yǒu yí ge píngguǒ.", "I have an apple."),
    ("工作", "gōngzuò", "work; job", "noun/verb", "我很喜欢这份工作。", "Wǒ hěn xǐhuan zhè fèn gōngzuò.", "I really like this job."),
    ("狗", "gǒu", "dog", "noun", "这只小狗很可爱。", "Zhè zhī xiǎogǒu hěn kě'ài.", "This puppy is very cute."),
    ("汉语", "Hànyǔ", "Chinese language", "noun", "汉语很有趣。", "Hànyǔ hěn yǒuqù.", "Chinese is very interesting."),
    ("好", "hǎo", "good; fine", "adjective", "天气真好。", "Tiānqì zhēn hǎo.", "The weather is really good."),
    ("喝", "hē", "to drink", "verb", "你想喝什么？", "Nǐ xiǎng hē shénme?", "What would you like to drink?"),
    ("和", "hé", "and; with", "conjunction", "我和他是同学。", "Wǒ hé tā shì tóngxué.", "He and I are classmates."),
    ("很", "hěn", "very", "adverb", "今天很热。", "Jīntiān hěn rè.", "Today is very hot."),
    ("后面", "hòumian", "behind; back", "noun", "他在我后面。", "Tā zài wǒ hòumian.", "He is behind me."),
    ("回", "huí", "to return; go back", "verb", "我想回家。", "Wǒ xiǎng huí jiā.", "I want to go home."),
    ("会", "huì", "can; know how to", "verb", "我会说一点汉语。", "Wǒ huì shuō yìdiǎn Hànyǔ.", "I can speak a little Chinese."),
    ("几", "jǐ", "how many (small number)", "pronoun", "你有几个朋友？", "Nǐ yǒu jǐ ge péngyou?", "How many friends do you have?"),
    ("家", "jiā", "home; family", "noun", "我家在河内。", "Wǒ jiā zài Hénèi.", "My home is in Hanoi."),
    ("叫", "jiào", "to call; be named", "verb", "他叫大卫。", "Tā jiào Dàwèi.", "His name is David."),
    ("今天", "jīntiān", "today", "noun", "今天是我的生日。", "Jīntiān shì wǒ de shēngrì.", "Today is my birthday."),
    ("九", "jiǔ", "nine", "numeral", "教室里有九个人。", "Jiàoshì lǐ yǒu jiǔ ge rén.", "There are nine people in the room."),
    ("开", "kāi", "to drive; to open", "verb", "请开门。", "Qǐng kāi mén.", "Please open the door."),
    ("看", "kàn", "to look; to see; to read", "verb", "我看了一本书。", "Wǒ kàn le yì běn shū.", "I read a book."),
    ("看见", "kànjiàn", "to see; catch sight of", "verb", "你看见我的钥匙了吗？", "Nǐ kànjiàn wǒ de yàoshi le ma?", "Did you see my keys?"),
    ("块", "kuài", "piece; dollar (colloquial)", "measure word", "这件衣服五十块。", "Zhè jiàn yīfu wǔshí kuài.", "This piece of clothing is 50 yuan."),
    ("来", "lái", "to come", "verb", "欢迎来我家玩。", "Huānyíng lái wǒ jiā wán.", "Welcome to come and visit my home."),
    ("老师", "lǎoshī", "teacher", "noun", "王老师人很好。", "Wáng lǎoshī rén hěn hǎo.", "Teacher Wang is very kind."),
    ("了", "le", "completed action / change particle", "particle", "下雨了。", "Xià yǔ le.", "It started to rain."),
    ("冷", "lěng", "cold", "adjective", "今天有点冷。", "Jīntiān yǒudiǎn lěng.", "Today is a bit cold."),
    ("里", "lǐ", "inside", "noun", "书在包里。", "Shū zài bāo lǐ.", "The book is inside the bag."),
    ("零", "líng", "zero", "numeral", "二零二六", "èr líng èr liù", "two zero two six"),
    ("六", "liù", "six", "numeral", "星期六有空吗？", "Xīngqīliù yǒu kòng ma?", "Are you free on Saturday?"),
    ("妈妈", "māma", "mother; mom", "noun", "妈妈做的菜最好吃。", "Māma zuò de cài zuì hǎochī.", "Mom's cooking is the tastiest."),
    ("吗", "ma", "question particle for yes/no", "particle", "你好吗？", "Nǐ hǎo ma?", "How are you?"),
    ("买", "mǎi", "to buy", "verb", "我想买一个新书包。", "Wǒ xiǎng mǎi yí ge xīn shūbāo.", "I want to buy a new backpack."),
    ("猫", "māo", "cat", "noun", "那只白猫在睡觉。", "Nà zhī bái māo zài shuìjiào.", "That white cat is sleeping."),
    ("没", "méi", "not have; did not", "adverb", "我没听懂。", "Wǒ méi tīng dǒng.", "I didn't understand what I heard."),
    ("没关系", "méi guānxi", "it doesn't matter; no problem", "phrase", "没关系，慢慢来。", "Méi guānxi, mànman lái.", "No problem, take your time."),
    ("米饭", "mǐfàn", "cooked rice", "noun", "中国人常吃米饭。", "Zhōngguórén cháng chī mǐfàn.", "Chinese people often eat cooked rice."),
    ("明天", "míngtiān", "tomorrow", "noun", "明天见！", "Míngtiān jiàn!", "See you tomorrow!"),
    ("名字", "míngzi", "name", "noun", "你叫什么名字？", "Nǐ jiào shénme míngzi?", "What is your name?"),
    ("哪", "nǎ", "which", "pronoun", "你想去哪儿？", "Nǐ xiǎng qù nǎr?", "Where do you want to go?"),
    ("那", "nà", "that", "pronoun", "那是我的电脑。", "Nà shì wǒ de diànnǎo.", "That is my computer."),
    ("呢", "ne", "particle for follow-up questions", "particle", "我很好，你呢？", "Wǒ hěn hǎo, nǐ ne?", "I am fine, and you?"),
    ("能", "néng", "can; to be able to", "verb", "你能帮我吗？", "Nǐ néng bāng wǒ ma?", "Can you help me?"),
    ("你", "nǐ", "you (singular)", "pronoun", "你喜欢中国吗？", "Nǐ xǐhuan Zhōngguó ma?", "Do you like China?"),
    ("年", "nián", "year", "noun", "我学了一年中文。", "Wǒ xué le yì nián Zhōngwén.", "I studied Chinese for a year."),
    ("女儿", "nǚ'ér", "daughter", "noun", "她女儿很漂亮。", "Tā nǚ'ér hěn piàoliang.", "Her daughter is very pretty."),
    ("朋友", "péngyou", "friend", "noun", "他是我的好朋友。", "Tā shì wǒ de hǎo péngyou.", "He is my good friend."),
    ("漂亮", "piàoliang", "pretty; beautiful", "adjective", "这件裙子很漂亮。", "Zhè jiàn qúnzi hěn piàoliang.", "This dress is very beautiful."),
    ("苹果", "píngguǒ", "apple", "noun", "我想吃一个苹果。", "Wǒ xiǎng chī yí ge píngguǒ.", "I want to eat an apple."),
    ("七", "qī", "seven", "numeral", "一个星期有七天。", "Yí ge xīngqī yǒu qī tiān.", "A week has seven days."),
    ("钱", "qián", "money", "noun", "我有足够的钱。", "Wǒ yǒu zúgòu de qián.", "I have enough money."),
    ("前面", "qiánmian", "in front; ahead", "noun", "学校在前面。", "Xuéxiào zài qiánmian.", "The school is ahead."),
    ("请", "qǐng", "please; to invite", "verb", "请坐！", "Qǐng zuò!", "Please sit down!"),
    ("去", "qù", "to go", "verb", "我们去图书馆吧。", "Wǒmen qù túshūguǎn ba.", "Let's go to the library."),
    ("热", "rè", "hot", "adjective", "今天太热了。", "Jīntiān tài rè le.", "Today is too hot."),
    ("人", "rén", "person; people", "noun", "他是一个好人。", "Tā shì yí ge hǎorén.", "He is a good person."),
    ("认识", "rènshi", "to know; recognize", "verb", "很高兴认识你。", "Hěn gāoxìng rènshi nǐ.", "Pleased to meet you."),
    ("三", "sān", "three", "numeral", "我有三个苹果。", "Wǒ yǒu sān ge píngguǒ.", "I have three apples."),
    ("商店", "shāngdiàn", "shop; store", "noun", "我去商店买牛奶。", "Wǒ qù shāngdiàn mǎi niúnǎi.", "I go to the store to buy milk."),
    ("上", "shàng", "up; on; above", "noun/verb", "桌子上有书。", "Zhuōzi shàng yǒu shū.", "There are books on the table."),
    ("上午", "shàngwǔ", "morning", "noun", "我上午有汉语课。", "Wǒ shàngwǔ yǒu Hànyǔ kè.", "I have Chinese class in the morning."),
    ("少", "shǎo", "few; little", "adjective", "这里的书很少。", "Zhèlǐ de shū hěn shǎo.", "There are few books here."),
    ("谁", "shéi", "who; whom", "pronoun", "他是谁？", "Tā shì shéi?", "Who is he?"),
    ("什么", "shénme", "what", "pronoun", "这是什么？", "Zhè shì shénme?", "What is this?"),
    ("十", "shí", "ten", "numeral", "我有十支笔。", "Wǒ yǒu shí zhī bǐ.", "I have ten pens."),
    ("时候", "shíhou", "time; moment", "noun", "你什么时候回来？", "Nǐ shénme shíhou huílái?", "When are you coming back?"),
    ("是", "shì", "to be (is/are/am)", "verb", "我是越南人。", "Wǒ shì Yuènánrén.", "I am Vietnamese."),
    ("书", "shū", "book", "noun", "这本书很有意思。", "Zhè běn shū hěn yǒuyìsi.", "This book is very interesting."),
    ("水", "shuǐ", "water", "noun", "多喝水对身体好。", "Duō hē shuǐ duì shēntǐ hǎo.", "Drinking water is good for health."),
    ("水果", "shuǐguǒ", "fruit", "noun", "多吃水果身体好。", "Duō chī shuǐguǒ shēntǐ hǎo.", "Eating more fruit is healthy."),
    ("睡觉", "shuìjiào", "to sleep", "verb", "我想睡觉了。", "Wǒ xiǎng shuìjiào le.", "I want to sleep now."),
    ("说话", "shuōhuà", "to speak; talk", "verb", "别大声说话。", "Bié dàshēng shuōhuà.", "Don't speak loudly."),
    ("四", "sì", "four", "numeral", "一年有四个季节。", "Yì nián yǒu sì ge jìjié.", "A year has four seasons."),
    ("岁", "suì", "years old (age)", "noun", "我今年二十岁。", "Wǒ jīnnián èrshí suì.", "I am twenty years old this year."),
    ("他", "tā", "he; him", "pronoun", "他是我的好朋友。", "Tā shì wǒ de hǎo péngyou.", "He is my good friend."),
    ("她", "tā", "she; her", "pronoun", "她喜欢看书。", "Tā xǐhuan kàn shū.", "She likes reading books."),
    ("太", "tài", "too; extremely", "adverb", "太好了！", "Tài hǎo le!", "That's great!"),
    ("天气", "tiānqì", "weather", "noun", "今天天气真好。", "Jīntiān tiānqì zhēn hǎo.", "The weather is really nice today."),
    ("听", "tīng", "to listen; hear", "verb", "他在听音乐。", "Tā zài tīng yīnyuè.", "He is listening to music."),
    ("同学", "tóngxué", "classmate", "noun", "我们是大学同学。", "Wǒmen shì dàxué tóngxué.", "We are college classmates."),
    ("喂", "wèi", "hello (on the phone)", "interjection", "喂，你在哪里？", "Wèi, nǐ zài nǎlǐ?", "Hello, where are you?"),
    ("我", "wǒ", "I; me", "pronoun", "我喜欢学中文。", "Wǒ xǐhuan xué Zhōngwén.", "I like learning Chinese."),
    ("我们", "wǒmen", "we; us", "pronoun", "我们一起去吧。", "Wǒmen yìqǐ qù ba.", "Let's go together."),
    ("五", "wǔ", "five", "numeral", "我有五本中文书。", "Wǒ yǒu wǔ běn Zhōngwén shū.", "I have five Chinese books."),
    ("喜欢", "xǐhuan", "to like", "verb", "我喜欢喝中国茶。", "Wǒ xǐhuan hē Zhōngguó chá.", "I like drinking Chinese tea."),
    ("下", "xià", "down; below; under", "noun/verb", "下课后我们去图书馆。", "Xiàkè hòu wǒmen qù túshūguǎn.", "After class we go to the library."),
    ("下午", "xiàwǔ", "afternoon", "noun", "今天下午开会。", "Jīntiān xiàwǔ kāihuì.", "There is a meeting this afternoon."),
    ("下雨", "xiàyǔ", "to rain", "verb", "外面在下雨。", "Wàimiàn zài xiàyǔ.", "It is raining outside."),
    ("先生", "xiānsheng", "Mr.; sir; husband", "noun", "李先生在办公室。", "Lǐ xiānsheng zài bàngōngshì.", "Mr. Li is in the office."),
    ("现在", "xiànzài", "now", "noun", "现在几点了？", "Xiànzài jǐ diǎn le?", "What time is it now?"),
    ("想", "xiǎng", "to want; to think; miss", "verb", "我想去中国旅游。", "Wǒ xiǎng qù Zhōngguó lǚyóu.", "I want to travel to China."),
    ("小", "xiǎo", "small; little", "adjective", "这间房间很小。", "Zhè jiān fángjiān hěn xiǎo.", "This room is very small."),
    ("小姐", "xiǎojiě", "Miss; young lady", "noun", "张小姐很有礼貌。", "Zhāng xiǎojiě hěn yǒu lǐmào.", "Miss Zhang is very polite."),
    ("些", "xiē", "some; a few", "measure word", "我买了一些水果。", "Wǒ mǎi le yìxiē shuǐguǒ.", "I bought some fruit."),
    ("写", "xiě", "to write", "verb", "他正在写汉字。", "Tā zhèngzài xiě hànzì.", "He is writing Chinese characters."),
    ("谢谢", "xièxie", "to thank; thanks", "verb", "谢谢你的礼物。", "Xièxie nǐ de lǐwù.", "Thank you for your gift."),
    ("星期", "xīngqī", "week", "noun", "一个星期有七天。", "Yí ge xīngqī yǒu qī tiān.", "A week has seven days."),
    ("学生", "xuésheng", "student", "noun", "他是汉语学生。", "Tā shì Hànyǔ xuésheng.", "He is a Chinese student."),
    ("学习", "xuéxí", "to study; learn", "verb", "我每天学习汉语。", "Wǒ měitiān xuéxí Hànyǔ.", "I study Chinese every day."),
    ("学校", "xuéxiào", "school", "noun", "我们的学校很大。", "Wǒmen de xuéxiào hěn dà.", "Our school is very big."),
    ("一", "yī", "one", "numeral", "我有一个问题。", "Wǒ yǒu yí ge wèntí.", "I have a question."),
    ("衣服", "yīfu", "clothes", "noun", "这件衣服真漂亮。", "Zhè jiàn yīfu zhēn piàoliang.", "These clothes are really beautiful."),
    ("医生", "yīshēng", "doctor", "noun", "医生让我多休息。", "Yīshēng ràng wǒ duō xiūxi.", "The doctor told me to rest more."),
    ("医院", "yīyuàn", "hospital", "noun", "他住在医院旁边。", "Tā zhù zài yīyuàn pángbiān.", "He lives next to the hospital."),
    ("椅子", "yǐzi", "chair", "noun", "请坐在椅子上。", "Qǐng zuò zài yǐzi shàng.", "Please sit on the chair."),
    ("有", "yǒu", "to have; there is", "verb", "你有什么问题吗？", "Nǐ yǒu shénme wèntí ma?", "Do you have any questions?"),
    ("月", "yuè", "month; moon", "noun", "下个月我去中国。", "Xià ge yuè wǒ qù Zhōngguó.", "Next month I go to China."),
    ("再见", "zàijiàn", "goodbye; see you again", "phrase", "明天见，再见！", "Míngtiān jiàn, zàijiàn!", "See you tomorrow, goodbye!"),
    ("在", "zài", "at; in; on / doing", "preposition/verb", "我在家里看书。", "Wǒ zài jiā lǐ kàn shū.", "I am reading at home."),
    ("怎么", "zěnme", "how; why", "pronoun", "这个字怎么读？", "Zhè ge zì zěnme dú?", "How do you read this character?"),
    ("怎么样", "zěnmeyàng", "how is it; how about", "pronoun", "今天天气怎么样？", "Jīntiān tiānqì zěnmeyàng?", "How is the weather today?"),
    ("这", "zhè", "this", "pronoun", "这是我的朋友。", "Zhè shì wǒ de péngyou.", "This is my friend."),
    ("中国", "Zhōngguó", "China", "noun", "我想了解中国文化。", "Wǒ xiǎng liǎojiě Zhōngguó wénhuà.", "I want to understand Chinese culture."),
    ("中午", "zhōngwǔ", "noon; midday", "noun", "我们中午十二点吃饭。", "Wǒmen zhōngwǔ shí'èr diǎn chīfàn.", "We eat at 12 noon."),
    ("住", "zhù", "to live; stay", "verb", "你住在哪里？", "Nǐ zhù zài nǎlǐ?", "Where do you live?"),
    ("桌子", "zhuōzi", "table; desk", "noun", "桌上有一台电脑。", "Zhuō shàng yǒu yì tái diànnǎo.", "There is a computer on the table."),
    ("字", "zì", "character; word", "noun", "这个汉字很难写。", "Zhè ge hànzì hěn nán xiě.", "This Chinese character is hard to write."),
    ("昨天", "zuótiān", "yesterday", "noun", "昨天下午下雨了。", "Zuótiān xiàwǔ xià yǔ le.", "It rained yesterday afternoon."),
    ("坐", "zuò", "to sit; travel by", "verb", "请坐下来喝杯茶。", "Qǐng zuò xiàlái hē bēi chá.", "Please sit down and have a cup of tea."),
    ("做", "zuò", "to do; make", "verb", "你在做什么？", "Nǐ zài zuò shénme?", "What are you doing?")
]

wid = 1001
for item in hsk1_list:
    add_word(wid, 1, item[0], item[1], item[2], item[3], item[4], item[5], item[6])
    wid += 1

# HSK 2 Samples (Expansion)
hsk2_list = [
    ("吧", "ba", "suggestion particle", "particle", "我们一起走吧。", "Wǒmen yìqǐ zǒu ba.", "Let's go together."),
    ("白", "bái", "white; clear", "adjective", "她喜欢白色的衣服。", "Tā xǐhuan báisè de yīfu.", "She likes white clothes."),
    ("百", "bǎi", "hundred", "numeral", "这本书有一百页。", "Zhè běn shū yǒu yì bǎi yè.", "This book has 100 pages."),
    ("帮助", "bāngzhù", "to help; assistance", "verb/noun", "多谢你的帮助。", "Duōxiè nǐ de bāngzhù.", "Thanks a lot for your help."),
    ("报纸", "bàozhǐ", "newspaper", "noun", "爸爸每天看报纸。", "Bàba měitiān kàn bàozhǐ.", "Dad reads newspaper every day."),
    ("比", "bǐ", "compare; than", "preposition", "今天比昨天冷。", "Jīntiān bǐ zuótiān lěng.", "Today is colder than yesterday."),
    ("别", "bié", "don't; other", "adverb", "别客气，随便坐。", "Bié kèqi, suíbiàn zuò.", "Don't be polite, sit anywhere."),
    ("长", "cháng", "long", "adjective", "他的头发很长。", "Tā de tóufa hěn cháng.", "His hair is very long."),
    ("唱歌", "chànggē", "to sing", "verb", "她唱歌很好听。", "Tā chànggē hěn hǎotīng.", "She sings very well."),
    ("穿", "chuān", "to wear; put on", "verb", "多穿点衣服，外面冷。", "Duō chuān diǎn yīfu, wàimiàn lěng.", "Wear more clothes, it's cold outside."),
    ("次", "cì", "number of times; order", "measure word", "这是我第一次来。", "Zhè shì wǒ dì-yī cì lái.", "This is my first time coming."),
    ("从", "cóng", "from", "preposition", "我从越南来。", "Wǒ cóng Yuènán lái.", "I come from Vietnam."),
    ("错", "cuò", "wrong; mistake", "adjective", "你说得没错。", "Nǐ shuō de méi cuò.", "You said it right."),
    ("打篮球", "dǎ lánqiú", "play basketball", "verb", "下午我们去打篮球吧。", "Xiàwǔ wǒmen qù dǎ lánqiú ba.", "Let's go play basketball this afternoon."),
    ("大家", "dàjiā", "everyone; all", "pronoun", "大家好！", "Dàjiā hǎo!", "Hello everyone!"),
    ("到", "dào", "to arrive; reach", "verb", "火车到了。", "Huǒchē dào le.", "The train arrived."),
    ("等", "děng", "to wait", "verb", "请稍等一下。", "Qǐng shāoděng yíxià.", "Please wait a moment."),
    ("弟弟", "dìdi", "younger brother", "noun", "我有一个可爱的弟弟。", "Wǒ yǒu yí ge kě'ài de dìdi.", "I have a cute younger brother."),
    ("懂", "dǒng", "to understand", "verb", "你懂汉语吗？", "Nǐ dǒng Hànyǔ ma?", "Do you understand Chinese?")
]

wid = 2001
for item in hsk2_list:
    add_word(wid, 2, item[0], item[1], item[2], item[3], item[4], item[5], item[6])
    wid += 1

# HSK 3 Samples
hsk3_list = [
    ("阿姨", "āyí", "aunt; nanny", "noun", "阿姨好！", "Āyí hǎo!", "Hello auntie!"),
    ("矮", "ǎi", "short; low", "adjective", "他比我矮一点。", "Tā bǐ wǒ ǎi yìdiǎn.", "He is a bit shorter than me."),
    ("安静", "ānjìng", "quiet; peaceful", "adjective", "请大家保持安静。", "Qǐng dàjiā bǎochí ānjìng.", "Please keep quiet everyone."),
    ("把", "bǎ", "grasp; hold; particle", "preposition", "把门关上。", "Bǎ mén guān shàng.", "Close the door."),
    ("搬", "bān", "to move; carry", "verb", "明天我们要搬家。", "Míngtiān wǒmen yào bān jiā.", "Tomorrow we are moving.")
]

wid = 3001
for item in hsk3_list:
    add_word(wid, 3, item[0], item[1], item[2], item[3], item[4], item[5], item[6])
    wid += 1

# HSK 4 Samples
hsk4_list = [
    ("爱情", "àiqíng", "romantic love", "noun", "这是一段美好的爱情。", "Zhè shì yí duàn měihǎo de àiqíng.", "This is a wonderful love story."),
    ("安排", "ānpái", "to arrange; plan", "verb/noun", "经理安排了工作。", "Jīnglǐ ānpái le gōngzuò.", "The manager arranged the work."),
    ("安全", "ānquán", "safe; safety", "adjective/noun", "祝你一路安全。", "Zhù nǐ yílù ānquán.", "Wish you a safe journey."),
    ("按时", "ànshí", "on time", "adverb", "请按时交作业。", "Qǐng ànshí jiāo zuòyè.", "Please hand in homework on time.")
]

wid = 4001
for item in hsk4_list:
    add_word(wid, 4, item[0], item[1], item[2], item[3], item[4], item[5], item[6])
    wid += 1

# HSK 5 Samples
hsk5_list = [
    ("爱护", "àihù", "to cherish; protect", "verb", "我们要爱护环境。", "Wǒmen yào àihù huánjìng.", "We must protect the environment."),
    ("爱惜", "àixī", "to treasure; use carefully", "verb", "爱惜粮食是美德。", "Àixī liángshí shì měidé.", "Cherishing grain is a virtue."),
    ("爱心", "àixīn", "compassion; loving heart", "noun", "她是个很有爱心的人。", "Tā shì ge hěn yǒu àixīn de rén.", "She is a person with a loving heart.")
]

wid = 5001
for item in hsk5_list:
    add_word(wid, 5, item[0], item[1], item[2], item[3], item[4], item[5], item[6])
    wid += 1

os.makedirs("app/src/main/assets", exist_ok=True)
with open("app/src/main/assets/hsk_words.json", "w", encoding="utf-8") as f:
    json.dump(words, f, ensure_ascii=False, indent=2)

print(f"Generated {len(words)} words into app/src/main/assets/hsk_words.json successfully!")
