# -*- coding: utf-8 -*-
import json
import os

with open("app/src/main/assets/hsk_words.json", "r", encoding="utf-8") as f:
    hsk_words = json.load(f)

json_data_str = json.dumps(hsk_words, ensure_ascii=False)

html_content = f"""<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
  <title>HSK Screen Tutor - Trình giả lập Học từ vựng Mở khóa Android</title>
  <link href="https://fonts.googleapis.com/css2?family=Ma+Shan+Zheng&family=Noto+Sans+SC:wght@400;700;900&family=Nunito:wght@400;600;700;800;900&display=swap" rel="stylesheet">
  <!-- Preloaded offline stroke dataset & Hanzi Writer Library -->
  <script src="strokes.js"></script>
  <script src="hanzi-writer.min.js"></script>
  <script>
    // Fallback to CDN if local script not accessible
    if (typeof HanziWriter === 'undefined') {{
      document.write('<script src="https://cdn.jsdelivr.net/npm/hanzi-writer@3.5/dist/hanzi-writer.min.js"><\\/script>');
    }}
  </script>
  <style>
    :root {{
      --primary: #1E88E5;
      --chinese-red: #D32F2F;
      --chinese-gold: #FFB300;
      --bg: #121212;
      --surface: #FFFFFF;
      --text: #212121;
      --muted: #757575;
      --grid-color: #EF9A9A;
    }}
    * {{
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-tap-highlight-color: transparent;
    }}
    body {{
      font-family: 'Nunito', sans-serif;
      background: #18191a;
      color: #fff;
      display: flex;
      flex-direction: column;
      align-items: center;
      min-height: 100vh;
      padding: 16px 8px;
    }}
    header {{
      text-align: center;
      margin-bottom: 12px;
      max-width: 600px;
    }}
    header h1 {{
      font-size: 22px;
      color: #FFD54F;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
    }}
    header p {{
      font-size: 13px;
      color: #B0BEC5;
      margin-top: 4px;
    }}
    .phone-container {{
      width: 100%;
      max-width: 425px;
      height: 880px;
      background: #000;
      border-radius: 46px;
      border: 8px solid #2C3437;
      box-shadow: 0 25px 60px rgba(0,0,0,0.8), 0 0 0 2px #444;
      position: relative;
      overflow: hidden;
      display: flex;
      flex-direction: column;
    }}
    .notch {{
      position: absolute;
      top: 0;
      left: 50%;
      transform: translateX(-50%);
      width: 140px;
      height: 24px;
      background: #2C3437;
      border-bottom-left-radius: 16px;
      border-bottom-right-radius: 16px;
      z-index: 100;
    }}
    .status-bar {{
      height: 38px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 6px 24px 0 24px;
      font-size: 12px;
      font-weight: 700;
      color: #fff;
      z-index: 90;
    }}

    /* Lock Screen Mode */
    .lockscreen {{
      flex: 1;
      background: linear-gradient(135deg, #1A237E, #0D47A1, #004D40);
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: space-between;
      padding: 60px 24px 40px;
      position: relative;
      transition: all 0.4s ease;
    }}
    .lock-clock {{
      text-align: center;
    }}
    .lock-time {{
      font-size: 64px;
      font-weight: 300;
      letter-spacing: -2px;
    }}
    .lock-date {{
      font-size: 14px;
      color: #E0E0E0;
      margin-top: -6px;
    }}
    .lock-notification {{
      background: rgba(255, 255, 255, 0.15);
      backdrop-filter: blur(12px);
      border-radius: 16px;
      padding: 14px 18px;
      width: 100%;
      border: 1px solid rgba(255,255,255,0.2);
    }}
    .lock-notification-title {{
      font-size: 13px;
      font-weight: 700;
      color: #FFF;
      display: flex;
      align-items: center;
      gap: 6px;
    }}
    .lock-notification-sub {{
      font-size: 12px;
      color: #E0E0E0;
      margin-top: 4px;
    }}
    .unlock-btn {{
      background: rgba(255,255,255,0.25);
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255,255,255,0.4);
      color: #FFF;
      padding: 14px 32px;
      border-radius: 30px;
      font-size: 15px;
      font-weight: 700;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s;
    }}
    .unlock-btn:hover {{
      background: rgba(255,255,255,0.4);
      transform: scale(1.05);
    }}

    /* Home Screen Mode */
    .homescreen {{
      flex: 1;
      background: #ECEFF1;
      color: #212121;
      display: flex;
      flex-direction: column;
      overflow-y: auto;
      padding: 16px;
      position: relative;
    }}
    .app-header {{
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 8px;
    }}

    /* HSK Level Switcher Bar */
    .hsk-level-bar {{
      display: flex;
      gap: 5px;
      background: #E0E0E0;
      padding: 4px;
      border-radius: 12px;
      margin-bottom: 12px;
    }}
    .level-tab-btn {{
      flex: 1;
      border: none;
      background: transparent;
      padding: 6px 2px;
      border-radius: 8px;
      font-size: 11px;
      font-weight: 800;
      color: #555;
      cursor: pointer;
      transition: all 0.15s;
      text-align: center;
    }}
    .level-tab-btn.active {{
      background: #FFFFFF;
      color: var(--chinese-red);
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }}

    .card {{
      background: #FFF;
      border-radius: 18px;
      padding: 14px;
      margin-bottom: 12px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    }}
    .stat-row {{
      display: flex;
      justify-content: space-around;
      text-align: center;
      margin-top: 8px;
    }}
    .stat-val {{
      font-size: 22px;
      font-weight: 800;
      color: var(--primary);
    }}
    .stat-lbl {{
      font-size: 11px;
      color: var(--muted);
      margin-top: 2px;
    }}

    /* VOCABULARY POPUP OVERLAY */
    .popup-overlay {{
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.72);
      backdrop-filter: blur(6px);
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 10px;
      z-index: 200;
      opacity: 0;
      pointer-events: none;
      transition: opacity 0.3s ease;
    }}
    .popup-overlay.active {{
      opacity: 1;
      pointer-events: auto;
    }}
    .popup-card {{
      background: #FFFFFF;
      width: 100%;
      border-radius: 24px;
      padding: 16px 14px;
      color: var(--text);
      box-shadow: 0 20px 40px rgba(0,0,0,0.4);
      transform: translateY(20px) scale(0.96);
      transition: all 0.3s cubic-bezier(0.18, 0.89, 0.32, 1.28);
      max-height: 98%;
      overflow-y: auto;
      display: flex;
      flex-direction: column;
    }}
    .popup-overlay.active .popup-card {{
      transform: translateY(0) scale(1);
    }}

    .popup-top-bar {{
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 2px;
    }}
    .hsk-badge {{
      background: var(--chinese-red);
      color: #fff;
      font-size: 11px;
      font-weight: 800;
      padding: 3px 8px;
      border-radius: 6px;
    }}
    .srs-info {{
      font-size: 11px;
      color: var(--muted);
      font-weight: 600;
    }}
    .btn-speaker {{
      background: #E3F2FD;
      border: none;
      width: 36px;
      height: 36px;
      border-radius: 50%;
      color: var(--primary);
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      transition: 0.15s;
    }}
    .btn-speaker:hover {{
      background: #BBDEFB;
      transform: scale(1.1);
    }}

    /* Main Word Section */
    .word-section {{
      text-align: center;
      padding: 2px 0 6px;
    }}
    .hanzi-main {{
      font-family: 'Noto Sans SC', sans-serif;
      font-size: 52px;
      font-weight: 900;
      line-height: 1.1;
      color: #111;
      letter-spacing: 4px;
    }}
    .pinyin-main {{
      font-size: 19px;
      font-weight: 700;
      color: var(--chinese-red);
      margin-top: 2px;
    }}
    .english-main {{
      font-size: 14px;
      font-weight: 600;
      color: #333;
      margin-top: 2px;
    }}

    /* Tianzige Writing Area */
    .tianzige-container {{
      background: #FFFDF7;
      border: 2px solid #EF9A9A;
      border-radius: 18px;
      padding: 10px;
      margin: 6px 0;
      display: flex;
      flex-direction: column;
      align-items: center;
    }}
    .tianzige-header {{
      width: 100%;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 13px;
      font-weight: 800;
      margin-bottom: 6px;
      color: #212121;
    }}

    /* Status Banner for Stroke Demonstration */
    .stroke-status-banner {{
      width: 100%;
      background: #E3F2FD;
      border-radius: 8px;
      padding: 4px 8px;
      margin-bottom: 6px;
      font-size: 11px;
      font-weight: 700;
      color: #0D47A1;
      text-align: center;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
    }}

    /* Multi-character selector chips */
    .char-selector-row {{
      display: flex;
      gap: 6px;
      margin-bottom: 8px;
      width: 100%;
      justify-content: center;
      flex-wrap: wrap;
    }}
    .char-chip {{
      background: #ECEFF1;
      border: 2px solid #CFD8DC;
      color: #37474F;
      padding: 4px 12px;
      border-radius: 18px;
      font-size: 13px;
      font-weight: 800;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 5px;
      transition: all 0.2s;
    }}
    .char-chip.active {{
      background: #FFEBEE;
      border-color: var(--chinese-red);
      color: var(--chinese-red);
      box-shadow: 0 2px 6px rgba(211,47,47,0.25);
      transform: scale(1.05);
    }}
    .char-chip .hanzi-glyph {{
      font-family: 'Noto Sans SC', sans-serif;
      font-size: 16px;
      font-weight: 900;
    }}

    /* 260px x 260px Canvas Stack Wrapper */
    .canvas-wrap {{
      position: relative;
      width: 260px;
      height: 260px;
      background-color: #FFFDF7;
      border: 2.5px solid #E57373;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(239, 154, 154, 0.2);
      overflow: hidden;
    }}
    
    /* Background Tianzige Grid Lines (Dashed Red) */
    .grid-lines-svg {{
      position: absolute;
      top: 0;
      left: 0;
      width: 260px;
      height: 260px;
      pointer-events: none;
      z-index: 1;
    }}

    /* Hanzi Writer Container (for stroke animation & quiz) */
    #hanziWriterTarget {{
      position: absolute;
      top: 0;
      left: 0;
      width: 260px;
      height: 260px;
      z-index: 2;
    }}

    /* Freehand Drawing Canvas */
    #drawingCanvas {{
      position: absolute;
      top: 0;
      left: 0;
      width: 260px;
      height: 260px;
      touch-action: none;
      cursor: crosshair;
      z-index: 3;
    }}

    /* Enhanced Controls Panel */
    .canvas-controls-main {{
      display: flex;
      width: 260px;
      gap: 6px;
      margin-top: 8px;
    }}
    .btn-demo-stroke {{
      flex: 1.4;
      background: linear-gradient(135deg, #D32F2F, #B71C1C);
      color: #FFF;
      border: none;
      padding: 8px 10px;
      border-radius: 10px;
      font-size: 12px;
      font-weight: 800;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      box-shadow: 0 2px 6px rgba(211,47,47,0.3);
      transition: all 0.2s;
    }}
    .btn-demo-stroke:hover {{
      transform: translateY(-1px);
      box-shadow: 0 4px 8px rgba(211,47,47,0.4);
    }}
    .btn-demo-stroke:active {{
      transform: scale(0.98);
    }}

    .btn-quiz-stroke {{
      flex: 1.1;
      background: linear-gradient(135deg, #0288D1, #01579B);
      color: #FFF;
      border: none;
      padding: 8px 8px;
      border-radius: 10px;
      font-size: 12px;
      font-weight: 800;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 4px;
      transition: all 0.2s;
    }}
    .btn-quiz-stroke:hover {{
      transform: translateY(-1px);
    }}

    .canvas-controls-sub {{
      display: flex;
      justify-content: space-between;
      width: 260px;
      gap: 6px;
      margin-top: 6px;
    }}
    .canvas-btn-sm {{
      background: #ECEFF1;
      border: 1px solid #CFD8DC;
      padding: 5px 8px;
      border-radius: 8px;
      font-size: 11px;
      font-weight: 700;
      color: #455A64;
      cursor: pointer;
      flex: 1;
      text-align: center;
      transition: 0.15s;
    }}
    .canvas-btn-sm:hover {{
      background: #CFD8DC;
    }}
    .canvas-btn-sm.danger {{
      color: var(--chinese-red);
      background: #FFEBEE;
      border-color: #FFCDD2;
    }}
    .canvas-btn-sm.next-char {{
      color: #1565C0;
      background: #E3F2FD;
      border-color: #BBDEFB;
      font-weight: 800;
    }}

    /* Example Box */
    .example-box {{
      background: #F0F4F8;
      border-radius: 12px;
      padding: 10px 14px;
      margin: 6px 0 10px;
    }}
    .example-header {{
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 11px;
      font-weight: 800;
      color: #1976D2;
      margin-bottom: 3px;
    }}
    .example-cn {{
      font-family: 'Noto Sans SC', sans-serif;
      font-size: 15px;
      font-weight: 700;
      color: #212121;
    }}
    .example-py {{
      font-size: 12px;
      color: var(--chinese-red);
      margin-top: 2px;
    }}
    .example-en {{
      font-size: 12px;
      color: #555;
      margin-top: 2px;
    }}

    /* Action Buttons */
    .action-row {{
      display: flex;
      gap: 10px;
    }}
    .btn-action {{
      flex: 1;
      padding: 12px;
      border-radius: 14px;
      border: none;
      font-size: 14px;
      font-weight: 800;
      cursor: pointer;
      transition: 0.15s;
    }}
    .btn-snooze {{
      background: #ECEFF1;
      color: #455A64;
    }}
    .btn-snooze:hover {{
      background: #CFD8DC;
    }}
    .btn-next {{
      background: var(--chinese-red);
      color: #FFF;
      flex: 1.4;
    }}
    .btn-next:hover {{
      background: #B71C1C;
    }}

    /* External Control Panel */
    .control-panel {{
      margin-top: 14px;
      background: #25282A;
      padding: 14px 18px;
      border-radius: 16px;
      max-width: 425px;
      width: 100%;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }}
    .panel-row {{
      display: flex;
      gap: 8px;
    }}
    .panel-btn {{
      background: #37474F;
      color: #ECEFF1;
      border: 1px solid #546E7A;
      padding: 8px 12px;
      border-radius: 10px;
      font-size: 12px;
      font-weight: 700;
      cursor: pointer;
      flex: 1;
      text-align: center;
    }}
    .panel-btn:hover {{
      background: var(--primary);
    }}
    .panel-level-select {{
      display: flex;
      gap: 4px;
      align-items: center;
      justify-content: space-between;
    }}
    .panel-level-btn {{
      background: #455A64;
      color: #FFF;
      border: none;
      padding: 6px 10px;
      border-radius: 6px;
      font-size: 11px;
      font-weight: 800;
      cursor: pointer;
      flex: 1;
    }}
    .panel-level-btn.active {{
      background: var(--chinese-red);
    }}
  </style>
</head>
<body>

  <header>
    <h1>🇨🇳 HSK Screen Tutor - Android Simulator</h1>
    <p>Học từ vựng mở khóa • Tích hợp Viết Mẫu Bút Thuận Chuẩn</p>
  </header>

  <div class="phone-container">
    <div class="notch"></div>
    <div class="status-bar">
      <span id="statusBarTime">08:30</span>
      <span>📶 5G &nbsp; 🔋 98%</span>
    </div>

    <!-- LOCK SCREEN VIEW -->
    <div class="lockscreen" id="lockScreenView">
      <div class="lock-clock">
        <div class="lock-time" id="lockClockTime">08:30</div>
        <div class="lock-date" id="lockDate">Thứ Bảy, 21 Tháng 11</div>
      </div>

      <div class="lock-notification">
        <div class="lock-notification-title">
          <span>🔔 HSK Screen Tutor • Đang kích hoạt</span>
        </div>
        <div class="lock-notification-sub" id="lockNotificationSub">
          7 từ vựng HSK 1 hôm nay đang chờ bạn. Mở khóa để học từ mới, xem viết mẫu & luyện viết!
        </div>
      </div>

      <button class="unlock-btn" onclick="unlockDevice()">
        🔓 Mở khóa điện thoại
      </button>
    </div>

    <!-- HOME SCREEN VIEW -->
    <div class="homescreen" id="homeScreenView" style="display: none;">
      <div class="app-header">
        <h2 style="font-size: 18px; font-weight: 800; color: #1E88E5;">HSK Screen Tutor</h2>
        <span class="hsk-badge" id="dashLevelBadge">HSK 1</span>
      </div>

      <!-- Level Switcher Tabs -->
      <div class="hsk-level-bar">
        <button class="level-tab-btn active" onclick="switchLevel(1)">HSK 1 (148)</button>
        <button class="level-tab-btn" onclick="switchLevel(2)">HSK 2 (152)</button>
        <button class="level-tab-btn" onclick="switchLevel(3)">HSK 3 (147)</button>
        <button class="level-tab-btn" onclick="switchLevel(4)">HSK 4 (125)</button>
        <button class="level-tab-btn" onclick="switchLevel(5)">HSK 5 (80)</button>
      </div>

      <div class="card">
        <div style="font-size: 14px; font-weight: 800;">Tiến độ học hôm nay</div>
        <div class="stat-row">
          <div>
            <div class="stat-val" id="statNewCount">7</div>
            <div class="stat-lbl">Từ mới hôm nay</div>
          </div>
          <div>
            <div class="stat-val" id="statTotalLevelWords" style="color: #FF8F00;">148</div>
            <div class="stat-lbl">Tổng từ cấp độ này</div>
          </div>
          <div>
            <div class="stat-val" id="statTodayViews" style="color: #2E7D32;">0</div>
            <div class="stat-lbl">Lần lặp lại</div>
          </div>
        </div>
      </div>

      <div class="card" style="background: #E8F5E9; border: 1px solid #C8E6C9;">
        <div style="font-size: 12px; font-weight: 700; color: #2E7D32;">
          ✅ Dịch vụ nền đang chạy (Foreground Service)
        </div>
        <div style="font-size: 11px; color: #388E3C; margin-top: 4px;">
          Tự động bật popup khi mở khóa điện thoại và sau mỗi chu kỳ hẹn giờ 30 phút.
        </div>
      </div>

      <div style="font-size: 13px; font-weight: 800; margin: 12px 0 6px;">
        Danh sách 7 từ mục tiêu hôm nay:
      </div>
      <div id="todayWordsList"></div>
    </div>

    <!-- VOCABULARY POPUP OVERLAY -->
    <div class="popup-overlay" id="popupOverlay">
      <div class="popup-card">
        <div class="popup-top-bar">
          <span class="hsk-badge" id="popupLevel">HSK 1</span>
          <span class="srs-info" id="popupSrsInfo">Lần xem: 1 | SRS Ngày 1</span>
          <button class="btn-speaker" onclick="speakCurrentWord()" title="Nghe phát âm">🔊</button>
        </div>

        <div class="word-section">
          <div class="hanzi-main" id="popupHanzi">爱</div>
          <div class="pinyin-main" id="popupPinyin">ài</div>
          <div class="english-main" id="popupEnglish">to love; affection (verb)</div>
        </div>

        <!-- Tianzige Handwriting Area with Animated Stroke Demonstration -->
        <div class="tianzige-container">
          <div class="tianzige-header">
            <span>✍️ Luyện viết chữ Hán</span>
            <span style="font-size: 11px; color: #757575;">Ô Điền/Mễ (260x260px)</span>
          </div>

          <!-- Status Banner for Stroke Demonstration / Quiz feedback -->
          <div class="stroke-status-banner" id="strokeStatusBanner">
            <span>💡 Bấm nút <b>"🎬 Viết mẫu"</b> để máy vẽ mẫu từng nét cho bạn xem</span>
          </div>

          <!-- Character Selector Tabs (For multi-character words like 爸爸, 出租车) -->
          <div class="char-selector-row" id="charSelectorRow" style="display: none;"></div>

          <!-- 260px Stack Canvas & HanziWriter Container -->
          <div class="canvas-wrap">
            <!-- Persistent Red Dashed Tianzige Guidelines -->
            <svg class="grid-lines-svg" viewBox="0 0 260 260">
              <line x1="0" y1="130" x2="260" y2="130" stroke="#EF9A9A" stroke-width="1.5" stroke-dasharray="8,6" />
              <line x1="130" y1="0" x2="130" y2="260" stroke="#EF9A9A" stroke-width="1.5" stroke-dasharray="8,6" />
              <line x1="0" y1="0" x2="260" y2="260" stroke="#EF9A9A" stroke-width="1" stroke-dasharray="8,6" />
              <line x1="260" y1="0" x2="0" y2="260" stroke="#EF9A9A" stroke-width="1" stroke-dasharray="8,6" />
            </svg>

            <!-- HanziWriter Layer (for animated demonstration & stroke quiz) -->
            <div id="hanziWriterTarget"></div>

            <!-- Freehand Drawing Canvas -->
            <canvas id="drawingCanvas" width="520" height="520"></canvas>
          </div>

          <!-- Primary Control Row: Viết mẫu & Chấm nét -->
          <div class="canvas-controls-main">
            <button class="btn-demo-stroke" onclick="playDemoAnimation()">
              <span>🎬 Viết mẫu (Xem trước)</span>
            </button>
            <button class="btn-quiz-stroke" onclick="startQuizMode()">
              <span>🎯 Chấm nét</span>
            </button>
          </div>

          <!-- Secondary Control Row -->
          <div class="canvas-controls-sub">
            <button class="canvas-btn-sm" onclick="switchToFreehand()">✍️ Tự viết</button>
            <button class="canvas-btn-sm" onclick="toggleGhostText()">👁️ <span id="btnGhostLabel">Ẩn mẫu</span></button>
            <button class="canvas-btn-sm danger" onclick="clearCanvas()">🗑️ Xóa nét</button>
            <button class="canvas-btn-sm next-char" id="btnNextChar" style="display: none;" onclick="goToNextChar()">Tiếp ❯</button>
          </div>
        </div>

        <!-- Example Sentence -->
        <div class="example-box">
          <div class="example-header">
            <span>Ví dụ câu thực tế</span>
            <button style="background:none; border:none; cursor:pointer;" onclick="speakExample()">🔊</button>
          </div>
          <div class="example-cn" id="popupExCn">我爱学汉语。</div>
          <div class="example-py" id="popupExPy">Wǒ ài xué Hànyǔ.</div>
          <div class="example-en" id="popupExEn">I love learning Chinese.</div>
        </div>

        <!-- Action Buttons -->
        <div class="action-row">
          <button class="btn-action btn-snooze" onclick="closePopup()">Để sau</button>
          <button class="btn-action btn-next" onclick="markMasteredAndNext()">Đã thuộc (Tiếp tục) 👉</button>
        </div>
      </div>
    </div>
  </div>

  <!-- EXTERNAL SIMULATOR CONTROLS -->
  <div class="control-panel">
    <div style="font-size: 12px; font-weight: 700; color: #B0BEC5;">CHỌN TRÌNH ĐỘ HSK ĐỂ THỬ NGHIỆM:</div>
    <div class="panel-level-select">
      <button class="panel-level-btn active" id="btnLvl1" onclick="switchLevel(1)">HSK 1</button>
      <button class="panel-level-btn" id="btnLvl2" onclick="switchLevel(2)">HSK 2</button>
      <button class="panel-level-btn" id="btnLvl3" onclick="switchLevel(3)">HSK 3</button>
      <button class="panel-level-btn" id="btnLvl4" onclick="switchLevel(4)">HSK 4</button>
      <button class="panel-level-btn" id="btnLvl5" onclick="switchLevel(5)">HSK 5</button>
    </div>
    <div class="panel-row">
      <button class="panel-btn" onclick="lockDevice()">🔒 Khóa màn hình</button>
      <button class="panel-btn" onclick="simulatePeriodicTimer()">⏰ Hẹn giờ 30p</button>
      <button class="panel-btn" onclick="triggerPopupDirectly()" style="background: var(--chinese-red);">⚡ Popup ngay</button>
    </div>
  </div>

  <script>
    // Embedded HSK Dataset (652 Words)
    const ALL_WORDS = {json_data_str};

    // State
    let currentHskLevel = 1;
    let dailyQuota = 7;
    let todayWords = [];
    let currentWord = null;
    let selectedCharIndex = 0;
    let showGhost = true;
    let totalEncountersToday = 0;

    // HanziWriter instance
    let hanziWriterInstance = null;
    let isWriterAnimating = false;

    // Freehand Canvas drawing state
    const canvas = document.getElementById('drawingCanvas');
    const ctx = canvas.getContext('2d');
    let isDrawing = false;
    let hasDrawn = false;

    function init() {{
      loadWordsForLevel(currentHskLevel);
      initCanvas();
      updateClock();
      setInterval(updateClock, 1000);
    }}

    function switchLevel(level) {{
      currentHskLevel = level;

      const buttons = document.querySelectorAll('.level-tab-btn');
      buttons.forEach((btn, idx) => {{
        btn.classList.toggle('active', (idx + 1) === level);
      }});

      for (let i = 1; i <= 5; i++) {{
        const pBtn = document.getElementById('btnLvl' + i);
        if (pBtn) pBtn.classList.toggle('active', i === level);
      }}

      loadWordsForLevel(level);
    }}

    function loadWordsForLevel(level) {{
      const levelWords = ALL_WORDS.filter(w => w.level === level);
      todayWords = levelWords.slice(0, dailyQuota).map(w => ({{
        ...w,
        viewsToday: 0,
        writesToday: 0,
        stage: 1
      }}));

      document.getElementById('dashLevelBadge').innerText = 'HSK ' + level;
      document.getElementById('statTotalLevelWords').innerText = levelWords.length;
      document.getElementById('lockNotificationSub').innerText = `7 từ vựng HSK ${{level}} hôm nay đang chờ bạn. Mở khóa để học từ mới, xem viết mẫu & luyện viết!`;

      updateDashboard();
    }}

    function updateClock() {{
      const now = new Date();
      const hrs = String(now.getHours()).padStart(2, '0');
      const mins = String(now.getMinutes()).padStart(2, '0');
      const timeStr = `${{hrs}}:${{mins}}`;
      document.getElementById('statusBarTime').innerText = timeStr;
      document.getElementById('lockClockTime').innerText = timeStr;
    }}

    function unlockDevice() {{
      document.getElementById('lockScreenView').style.display = 'none';
      document.getElementById('homeScreenView').style.display = 'flex';
      showNextWordPopup();
    }}

    function lockDevice() {{
      closePopup();
      document.getElementById('homeScreenView').style.display = 'none';
      document.getElementById('lockScreenView').style.display = 'flex';
    }}

    function simulatePeriodicTimer() {{
      showNextWordPopup();
    }}

    function triggerPopupDirectly() {{
      showNextWordPopup();
    }}

    function setStatus(html) {{
      document.getElementById('strokeStatusBanner').innerHTML = html;
    }}

    function showNextWordPopup(forcedWord = null) {{
      if (forcedWord) {{
        currentWord = forcedWord;
      }} else {{
        const minViews = Math.min(...todayWords.map(w => w.viewsToday));
        const candidates = todayWords.filter(w => w.viewsToday === minViews);
        currentWord = candidates[Math.floor(Math.random() * candidates.length)];
      }}

      currentWord.viewsToday++;
      totalEncountersToday++;
      updateDashboard();

      selectedCharIndex = 0;

      // Render popup details
      document.getElementById('popupLevel').innerText = 'HSK ' + currentWord.level;
      document.getElementById('popupHanzi').innerText = currentWord.hanzi;
      document.getElementById('popupPinyin').innerText = currentWord.pinyin;
      document.getElementById('popupEnglish').innerText = currentWord.english + ' (' + currentWord.partOfSpeech + ')';
      document.getElementById('popupSrsInfo').innerText = `Lần xem hôm nay: ${{currentWord.viewsToday}} | Ngày 1`;

      document.getElementById('popupExCn').innerText = currentWord.exampleCn;
      document.getElementById('popupExPy').innerText = currentWord.examplePinyin;
      document.getElementById('popupExEn').innerText = currentWord.exampleEn;

      renderCharacterTabs();
      initHanziWriterForCurrentChar();

      document.getElementById('popupOverlay').classList.add('active');
      speak(currentWord.hanzi);
    }}

    function renderCharacterTabs() {{
      const selectorRow = document.getElementById('charSelectorRow');
      const btnNextChar = document.getElementById('btnNextChar');
      const chars = Array.from(currentWord.hanzi);

      if (chars.length > 1) {{
        selectorRow.style.display = 'flex';
        selectorRow.innerHTML = '';
        btnNextChar.style.display = 'inline-block';

        chars.forEach((char, idx) => {{
          const chip = document.createElement('button');
          chip.className = 'char-chip' + (idx === selectedCharIndex ? ' active' : '');
          chip.innerHTML = `<span>Chữ ${{idx + 1}}:</span> <span class="hanzi-glyph">${{char}}</span>`;
          chip.onclick = () => {{
            selectedCharIndex = idx;
            renderCharacterTabs();
            initHanziWriterForCurrentChar();
          }};
          selectorRow.appendChild(chip);
        }});
      }} else {{
        selectorRow.style.display = 'none';
        btnNextChar.style.display = 'none';
      }}
    }}

    function goToNextChar() {{
      const chars = Array.from(currentWord.hanzi);
      if (selectedCharIndex < chars.length - 1) {{
        selectedCharIndex++;
      }} else {{
        selectedCharIndex = 0;
      }}
      renderCharacterTabs();
      initHanziWriterForCurrentChar();
    }}

    function getCurrentChar() {{
      if (!currentWord) return '';
      const chars = Array.from(currentWord.hanzi);
      return chars[selectedCharIndex] || chars[0] || '';
    }}

    // Setup HanziWriter for animated demonstration
    function initHanziWriterForCurrentChar() {{
      const char = getCurrentChar();
      const target = document.getElementById('hanziWriterTarget');
      target.innerHTML = '';

      clearCanvas();
      switchToFreehand();
      setStatus(`💡 Bấm <b>"🎬 Viết mẫu"</b> để xem thứ tự viết chữ <b>${{char}}</b>`);

      try {{
        if (typeof HanziWriter !== 'undefined') {{
          hanziWriterInstance = HanziWriter.create('hanziWriterTarget', char, {{
            width: 260,
            height: 260,
            padding: 22,
            showOutline: showGhost,
            strokeAnimationSpeed: 1, // 1x normal speed for clear viewing
            delayBetweenStrokes: 220, // 220ms delay between consecutive strokes
            strokeColor: '#D32F2F', // Vivid red brush stroke for demo
            outlineColor: '#D7DADC',
            drawingColor: '#1A1A1A',
            drawingWidth: 20,
            showCharacter: false,
            highlightColor: '#FF6F00',
            showHintAfterMisses: 1,
            charDataLoader: function(char, onComplete) {{
              if (window.HANZI_STROKES && window.HANZI_STROKES[char]) {{
                onComplete(window.HANZI_STROKES[char]);
              }} else {{
                fetch('https://cdn.jsdelivr.net/npm/hanzi-writer-data@2.0/' + encodeURIComponent(char) + '.json')
                  .then(r => r.json()).then(onComplete).catch(console.error);
              }}
            }}
          }});
        }}
      }} catch (e) {{
        console.warn('HanziWriter init fallback:', e);
      }}

      drawGhostOnCanvas();
    }}

    // PLAY ANIMATED STROKE DEMONSTRATION ("VIẾT MẪU")
    function playDemoAnimation() {{
      const char = getCurrentChar();
      clearCanvas();

      // Show HanziWriter layer, hide drawing canvas temporarily
      canvas.style.display = 'none';
      document.getElementById('hanziWriterTarget').style.display = 'block';

      if (hanziWriterInstance) {{
        setStatus(`🎬 <b>Đang viết mẫu chữ "${{char}}"</b> theo thứ tự bút thuận chuẩn...`);
        isWriterAnimating = true;

        hanziWriterInstance.hideCharacter();
        hanziWriterInstance.animateCharacter({{
          onComplete: function() {{
            isWriterAnimating = false;
            setStatus(`✅ <b>Đã viết xong mẫu chữ "${{char}}"!</b> Giờ bạn hãy tự viết lại hoặc bấm "Chấm nét".`);
            // Automatically switch back to drawing canvas so user can trace right over it!
            setTimeout(() => {{
              canvas.style.display = 'block';
            }}, 800);
          }}
        }});
      }} else {{
        // Fallback demo animation using canvas sweep
        fallbackCanvasAnimation();
      }}
    }}

    // Interactive Stroke Quiz Mode ("Chấm nét")
    function startQuizMode() {{
      const char = getCurrentChar();
      clearCanvas();
      canvas.style.display = 'none';
      document.getElementById('hanziWriterTarget').style.display = 'block';

      if (hanziWriterInstance) {{
        setStatus(`🎯 <b>Hãy viết từng nét chữ "${{char}}"</b> bằng ngón tay/chuột theo thứ tự:`);
        hanziWriterInstance.quiz({{
          onMistake: function(strokeData) {{
            setStatus(`❌ Sai nét số ${{strokeData.strokeNum + 1}}! Hãy đồ theo gợi ý màu cam.`);
          }},
          onCorrectStroke: function(strokeData) {{
            setStatus(`✨ Đúng nét số ${{strokeData.strokeNum + 1}}! Còn ${{strokeData.strokesRemaining}} nét.`);
          }},
          onComplete: function(summaryData) {{
            setStatus(`🎉 <b>Tuyệt vời!</b> Bạn đã viết hoàn hảo chữ <b>${{char}}</b>!`);
            speak(char);
            setTimeout(() => {{
              canvas.style.display = 'block';
            }}, 1500);
          }}
        }});
      }}
    }}

    function switchToFreehand() {{
      canvas.style.display = 'block';
      setStatus(`✍️ <b>Tự vẽ tự do:</b> Dùng ngón tay hoặc chuột viết vào ô Điền/Mễ`);
    }}

    function fallbackCanvasAnimation() {{
      setStatus(`🎬 Đang mô phỏng nét viết...`);
      let progress = 0;
      const interval = setInterval(() => {{
        progress += 0.08;
        if (progress >= 1) {{
          clearInterval(interval);
          setStatus(`✅ Hoàn thành mẫu! Hãy tự vẽ lại.`);
          canvas.style.display = 'block';
        }}
      }}, 50);
    }}

    function closePopup() {{
      document.getElementById('popupOverlay').classList.remove('active');
    }}

    function markMasteredAndNext() {{
      closePopup();
      updateDashboard();
    }}

    function updateDashboard() {{
      document.getElementById('statNewCount').innerText = todayWords.length;
      document.getElementById('statTodayViews').innerText = totalEncountersToday;

      const listDiv = document.getElementById('todayWordsList');
      listDiv.innerHTML = '';
      todayWords.forEach(w => {{
        const item = document.createElement('div');
        item.style = 'background:#FFF; border-radius:12px; padding:10px 14px; margin-bottom:8px; display:flex; align-items:center; box-shadow:0 1px 3px rgba(0,0,0,0.05); cursor:pointer;';
        item.innerHTML = `
          <div style="font-size:24px; font-weight:900; color:#D32F2F; width:48px; font-family:'Noto Sans SC';">${{w.hanzi}}</div>
          <div style="flex:1; margin-left:8px;">
            <div style="font-size:13px; font-weight:700; color:#1E88E5;">${{w.pinyin}} <span style="font-size:10px; background:#E3F2FD; color:#0D47A1; padding:1px 6px; border-radius:4px;">Lặp lại: ${{w.viewsToday}} lần</span></div>
            <div style="font-size:12px; color:#424242;">${{w.english}}</div>
          </div>
          <button style="border:none; background:none; font-size:16px; cursor:pointer;" onclick="event.stopPropagation(); speak('${{w.hanzi}}')">🔊</button>
        `;
        item.onclick = () => {{
          showNextWordPopup(w);
        }};
        listDiv.appendChild(item);
      }});
    }}

    // Text To Speech
    function speak(text) {{
      if ('speechSynthesis' in window) {{
        window.speechSynthesis.cancel();
        const utter = new SpeechSynthesisUtterance(text);
        utter.lang = 'zh-CN';
        utter.rate = 0.85;
        window.speechSynthesis.speak(utter);
      }}
    }}
    function speakCurrentWord() {{
      if (currentWord) speak(currentWord.hanzi);
    }}
    function speakExample() {{
      if (currentWord) speak(currentWord.exampleCn);
    }}

    // Freehand Canvas drawing
    function initCanvas() {{
      canvas.addEventListener('mousedown', startDrawing);
      canvas.addEventListener('mousemove', draw);
      canvas.addEventListener('mouseup', stopDrawing);
      canvas.addEventListener('mouseleave', stopDrawing);

      canvas.addEventListener('touchstart', (e) => {{
        e.preventDefault();
        const touch = e.touches[0];
        startDrawing({{ clientX: touch.clientX, clientY: touch.clientY }});
      }});
      canvas.addEventListener('touchmove', (e) => {{
        e.preventDefault();
        const touch = e.touches[0];
        draw({{ clientX: touch.clientX, clientY: touch.clientY }});
      }});
      canvas.addEventListener('touchend', stopDrawing);
    }}

    function drawGhostOnCanvas() {{
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const activeChar = getCurrentChar();
      if (showGhost && activeChar) {{
        ctx.fillStyle = '#D7DADC';
        ctx.font = '900 370px "Noto Sans SC", "Ma Shan Zheng", sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(activeChar, canvas.width / 2, canvas.height / 2 + 18);
      }}
    }}

    function getCanvasPos(e) {{
      const rect = canvas.getBoundingClientRect();
      const scaleX = canvas.width / rect.width;
      const scaleY = canvas.height / rect.height;
      return {{
        x: (e.clientX - rect.left) * scaleX,
        y: (e.clientY - rect.top) * scaleY
      }};
    }}

    function startDrawing(e) {{
      isDrawing = true;
      hasDrawn = true;
      const pos = getCanvasPos(e);
      ctx.beginPath();
      ctx.moveTo(pos.x, pos.y);
    }}

    function draw(e) {{
      if (!isDrawing) return;
      const pos = getCanvasPos(e);
      ctx.lineWidth = 22;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.strokeStyle = '#1A1A1A';
      ctx.lineTo(pos.x, pos.y);
      ctx.stroke();
    }}

    function stopDrawing() {{
      if (isDrawing && currentWord) {{
        currentWord.writesToday = (currentWord.writesToday || 0) + 1;
      }}
      isDrawing = false;
    }}

    function clearCanvas() {{
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      drawGhostOnCanvas();
      if (hanziWriterInstance) {{
        try {{
          hanziWriterInstance.cancelQuiz();
          hanziWriterInstance.hideCharacter();
        }} catch(e) {{}}
      }}
    }}

    function toggleGhostText() {{
      showGhost = !showGhost;
      document.getElementById('btnGhostLabel').innerText = showGhost ? 'Ẩn mẫu' : 'Hiện mẫu';
      if (hanziWriterInstance) {{
        if (showGhost) hanziWriterInstance.showOutline();
        else hanziWriterInstance.hideOutline();
      }}
      drawGhostOnCanvas();
    }}

    window.onload = init;
  </script>
</body>
</html>
"""

os.makedirs("web_preview", exist_ok=True)
with open("web_preview/index.html", "w", encoding="utf-8") as f:
    f.write(html_content)

print(f"Web preview updated with Animated Stroke Demonstration successfully!")
