# -*- coding: utf-8 -*-
import json

from generate_full_breakdowns import BREAKDOWNS_HSK1_HSK2, BREAKDOWNS_HSK3

BREAKDOWNS_HSK4 = {
    "爱情": "Ái 爱 (tình yêu ôm lấy trái tim) + Tình 情 (bộ Tâm đứng 忄+ Thanh 青: tâm tình) -> Tình yêu đôi lứa",
    "安排": "An 安 (bình an) + Bài 排 (bộ Thủ 扌tay sắp xếp hàng ngũ) -> Sắp xếp, bố trí công việc",
    "安全": "An 安 (bộ Miên 宀 nhà ấm) + Toàn 全 (bộ Nhân 人 + Vương 玉: ngọc vẹn toàn) -> An toàn, yên ổn",
    "按时": "Án 按 (bộ Thủ 扌tay ấn định) + Thời 时 (giờ giấc) -> Đúng giờ, đúng hẹn",
    "按照": "Án 按 (dựa theo) + Chiếu 照 (bộ Nhật 日 + Chiếu 召: soi chiếu theo) -> Dựa theo, chiếu theo",
    "保证": "Bảo 保 (bộ Nhân đứng 亻ôm con che chở) + Chứng 证 (bộ Ngôn 讠+ Chính 正: lời chứng minh) -> Đảm bảo, cam đoan",
    "报名": "Báo 报 (bộ Thủ 扌tay dâng tin) + Danh 名 (tên tuổi) -> Ghi danh, đăng ký",
    "抱歉": "Bão 抱 (bộ Thủ 扌tay ôm lấy) + Khiểm 歉 (bộ Khiếm 欠: trong lòng hối tiếc) -> Xin lỗi, lấy làm tiếc",
    "保护": "Bảo 保 (che chở) + Hộ 护 (bộ Ngôn 讠+ Hộ 户: cánh cửa bảo vệ) -> Bảo vệ, gìn giữ",
    "倍": "Bộ Nhân đứng 亻(người) + Bồi 咅 -> Tăng lên gấp bội, lần",
    "毕业": "Tất 毕 (hoàn thành) + Nghiệp 业 (sự nghiệp học hành) -> Tốt nghiệp ra trường",
    "表达": "Biểu 表 (bày tỏ ra ngoài) + Đạt 达 (bộ Xước 辶: thông đạt) -> Bày tỏ, diễn đạt ý tứ",
    "表格": "Biểu 表 (bảng biểu) + Cách 格 (bộ Mộc 木: khung ô vuông vức) -> Bảng biểu, biểu mẫu",
    "表扬": "Biểu 表 (thể hiện) + Dương 扬 (bộ Thủ 扌tay giơ cao khen ngợi) -> Tuyên dương, khen ngợi",
    "标准": "Tiêu 标 (bộ Mộc 木: cột mốc) + Chuẩn 准 (bộ Thủy 冫+ Chuẩn 隹: mực nước chuẩn) -> Tiêu chuẩn, chuẩn mực",
    "饼干": "Bính 饼 (bộ Thực 饣bột bánh nướng) + Can 干 (khô giòn) -> Bánh quy khô giòn",
    "并且": "Tịnh 并 (song hành cùng lúc) + Thả 且 -> Đồng thời, và, hơn nữa",
    "博士": "Bác 博 (bộ Thập 十 uyên bác rộng lớn) + Sĩ 士 (bậc trí thức) -> Tiến sĩ",
    "不管": "Bất 不 (không) + Quản 管 (bộ Trúc ⺮ ống sáo: quản lý) -> Bất kể, cho dù",
    "不好意思": "Bất hảo 不好 (không hay) + Ý tứ 意思 -> Ngại ngùng, xấu hổ, áy náy",
    "材料": "Tài 材 (bộ Mộc 木 gỗ cây làm việc) + Liệu 料 (bộ Mễ 米 cân đong hạt) -> Tài liệu, nguyên vật liệu",
    "参观": "Tham 参 (tham gia) + Quan 观 (bộ Kiến 见: ngắm nhìn quan sát) -> Tham quan, thưởng ngoạn",
    "餐厅": "Xán 餐 (bộ Thực 食 ăn uống bữa cơm) + Sảnh 厅 (phòng rộng có mái che) -> Nhà hàng ăn uống",
    "差不多": "Sai 差 (chênh lệch) + Bất 不 + Đa 多 (nhiều) -> Xấp xỉ, gần như, suýt soát",
    "长城": "Trường 长 (dài vạn dặm) + Thành 城 (tường thành đất đắp) -> Vạn Lý Trường Thành",
    "超过": "Siêu 超 (bộ Tẩu 走: chạy vượt lên) + Quá 过 (bước qua) -> Vượt quá, vượt qua",
    "成功": "Thành 成 (hoàn thành) + Công 功 (bộ Lực 力 sức mạnh tạo công quả) -> Thành công, thắng lợi",
    "诚实": "Thành 诚 (bộ Ngôn 讠lời nói chân thành) + Thực 实 (bộ Miên 宀 nhà đầy của cải) -> Thành thật, trung thực",
    "成熟": "Thành 成 (trở thành) + Thục 熟 (bộ Hỏa 灬: nấu chín, hiểu thấu) -> Chín muồi, trưởng thành",
    "重新": "Trọng 重 (lặp lại gánh nặng) + Tân 新 (mới mẻ) -> Làm lại từ đầu, một lần nữa",
    "出差": "Xuất 出 (ra ngoài) + Sai 差 (sai phái công vụ) -> Đi công tác xa",
    "出生": "Xuất 出 (chui ra khỏi lòng mẹ) + Sinh 生 (sinh ra đời) -> Sinh ra, chào đời",
    "粗心": "Thô 粗 (bộ Mễ 米 hạt gạo to thô ráp) + Tâm 心 (trái tim) -> Bất cẩn, cẩu thả, không chu đáo",
    "存": "Bộ Tử 子 (đứa trẻ) + Thổ 土 (nền đất) -> Tích lũy gìn giữ, gửi tiền tiết kiệm",
    "错误": "Thác 错 (đúc kim loại lỗi) + Ngộ 误 (bộ Ngôn 讠lời nói sai lầm) -> Sai lầm, lỗi sai",
    "答案": "Đáp 答 (bộ Trúc ⺮ trả lời) + Án 案 (bộ Mộc 木 bàn án phân xử) -> Đáp án, lời giải",
    "打扮": "Đả 打 (tay) + Bàn 扮 (bộ Thủ 扌trang điểm hóa trang) -> Trang điểm, ăn diện làm đẹp",
    "打扰": "Đả 打 + Nhiễu 扰 (bộ Thủ 扌tay khuấy động quấy rầy) -> Quấy rầy, làm phiền",
    "打印": "Đả 打 + Ấn 印 (bàn tay cầm con dấu ấn xuống giấy) -> In ấn tài liệu",
    "打折": "Đả 打 + Chiết 折 (bộ Thủ 扌tay bẻ gãy bớt giá tiền) -> Giảm giá, chiết khấu",
    "大概": "Đại 大 + Khái 概 (bộ Mộc 木 gạt ngang thùng đong thóc) -> Đại khái, khoảng chừng",
    "大使馆": "Đại sứ 大使 + Quán 馆 (tòa nhà ngoại giao lớn) -> Đại sứ quán",
    "代表": "Đại 代 (bộ Nhân đứng 亻thay thế) + Biểu 表 (đại diện ra ngoài) -> Đại biểu, đại diện",
    "到处": "Đáo 到 (tới nơi) + Xứ 处 (nơi chốn) -> Khắp nơi, mọi nơi",
    "到底": "Đáo 到 (đến) + Để 底 (bộ Quảng 广 mái nhà + Để: đáy cùng) -> Đến cùng, rốt cuộc là",
    "道歉": "Đạo 道 (nói ra đạo lý) + Khiểm 歉 (bộ Khiếm 欠 hối tiếc) -> Nói lời xin lỗi",
    "得意": "Đắc 得 (đạt được) + Ý 意 (tâm ý như nguyện) -> Đắc ý, tự mãn đắc chí",
    "登机牌": "Đăng 登 (bước chân lên) + Cơ 机 (máy bay) + Bài 牌 (thẻ bài) -> Thẻ lên máy bay (Boarding pass)",
    "地址": "Địa 地 (đất đai) + Chỉ 址 (bộ Thổ 土 nền móng nhà) -> Địa chỉ cư ngụ",
    "调查": "Điều 调 (bộ Ngôn 讠hỏi han điều tra) + Tra 查 (soi xét) -> Điều tra, khảo sát",
    "掉": "Bộ Thủ 扌(bàn tay) + Trác 卓 -> Đánh rơi, rơi rụng xuống đất",
    "丢": "Bộ Nhất 一 + Khứ 去 (bỏ đi rơi mất) -> Đánh mất, vứt bỏ",
    "堵车": "Đổ 堵 (bộ Thổ 土 bức tường đất chắn ngang) + Xa 车 (xe cộ) -> Kẹt xe, tắc đường",
    "肚子": "Đỗ 肚 (bộ Nguyệt 月 thịt thân thể + Thổ 土 bụng to) + Tử 子 -> Bụng, dạ dày",
    "断": "Bộ Mễ 米 (hạt chia) + Cân 斤 (cái rìu chặt đôi) -> Chặt đứt, gãy lìa",
    "发生": "Phát 发 (phát sinh) + Sinh 生 (sinh ra) -> Xảy ra, phát sinh chuyện",
    "发展": "Phát 发 + Triển 展 (bộ Thi 尸: mở rộng tấm áo) -> Phát triển, tiến bộ",
    "法律": "Pháp 法 (phép tắc như mặt nước phẳng) + Luật 律 (bộ Xích 彳đường đi ngay thẳng) -> Pháp luật",
    "翻译": "Phiên 翻 (lật qua lại đôi cánh) + Dịch 译 (bộ Ngôn 讠chuyển ngữ) -> Dịch thuật, phiên dịch",
    "烦恼": "Phiền 烦 (bộ Hỏa 火 lửa đốt + Hiệt 页 nóng đầu) + Não 恼 (bộ Tâm đứng 忄đau đầu) -> Phiền muộn, rầu rĩ",
    "反对": "Phản 反 (bàn tay lật ngược lại) + Đối 对 (đối kháng) -> Phản đối, chống lại",
    "方法": "Phương 方 (hướng) + Pháp 法 (phép tắc chuẩn mực) -> Phương pháp, cách thức",
    "方向": "Phương 方 + Hướng 向 (cửa sổ trổ về phía trước) -> Phương hướng, chiều hướng",
    "房东": "Phòng 房 (căn nhà) + Đông 东 (chủ nhà ngồi phía Đông tiếp khách) -> Chủ nhà trọ, chủ nhà cho thuê",
    "放弃": "Phóng 放 (thả tay ra) + Khí 弃 (vứt bỏ đi) -> Từ bỏ, buông xuôi",
    "放松": "Phóng 放 (thả lỏng) + Tùng 松 (cây thông reo trong gió nhẹ) -> Thư giãn, thả lỏng tâm trí",
    "费用": "Phí 费 (bộ Bối 贝 tiền bạc chi tiêu) + Dụng 用 (sử dụng) -> Chi phí, tiền phí",
    "丰富": "Phong 丰 (bông lúa trĩu hạt) + Phú 富 (bộ Miên 宀 nhà đầy thóc ruộng) -> Phong phú, dồi dào",
    "否则": "Phủ 否 (bộ Bất 不 + Khẩu 口: phủ nhận) + Tắc 则 (quy tắc) -> Nếu không thì, bằng không",
    "符合": "Phù 符 (bộ Trúc ⺮ thẻ tre khớp nối) + Hợp 合 (hòa hợp) -> Phù hợp, ăn khớp",
    "复杂": "Phức 复 (nhiều tầng lớp chồng chéo) + Tạp 杂 (nhiều màu sắc đan xen) -> Phức tạp, rắc rối",
    "改变": "Cải 改 (bộ Kỷ 己 + Phác 攵: uốn nắn bản thân) + Biến 变 (biến hóa) -> Cải biến, thay đổi",
    "感动": "Cảm 感 (trái tim rung động) + Động 动 (lay động) -> Cảm động, xúc động nghẹn ngào",
    "感觉": "Cảm 感 (cảm nhận) + Giác 觉 (thấu hiểu) -> Cảm giác, cảm thấy",
    "感情": "Cảm 感 (cảm xúc) + Tình 情 (bộ Tâm đứng 忄tâm tình) -> Tình cảm, cảm xúc",
    "感谢": "Cảm 感 (lòng biết ơn) + Tạ 谢 (nói lời cảm ơn) -> Cảm tạ, chân thành cảm ơn",
    "高级": "Cao 高 (lầu cao) + Cấp 级 (bộ Mịch 纟nấc thang sợi dệt) -> Cao cấp, cấp bậc cao",
    "高速公路": "Cao tốc 高速 + Công lộ 公路 (đường bộ công cộng) -> Đường cao tốc",
    "工资": "Công 工 (sức lao động) + Tư 资 (bộ Bối 贝 tiền vốn trả công) -> Tiền lương, thù lao",
    "共同": "Cộng 共 (hai tay cùng nâng lên) + Đồng 同 (cùng một lòng) -> Cùng chung, chung nhau",
    "购物": "Cấu 购 (bộ Bối 贝 tiền mua sắm) + Vật 物 (đồ đạc) -> Mua sắm đồ vật",
    "估计": "Cô 估 (bộ Nhân đứng 亻định giá) + Kế 计 (bộ Ngôn 讠tính toán) -> Ước lượng, ước tính",
    "鼓励": "Cổ 鼓 (trống da gõ vang) + Lệ 励 (bộ Lực 力 khích lệ sức mạnh) -> Cổ vũ, động viên",
    "故意": "Cố 故 (chủ ý có sẵn) + Ý 意 (tâm ý) -> Cố tình, cố ý làm",
    "关键": "Quan 关 (cửa then chốt) + Kiện 键 (bộ Kim 钅chốt then cài bằng sắt) -> Điểm mấu chốt, then chốt",
    "观众": "Quan 观 (mắt nhìn ngắm) + Chúng 众 (ba người 人 tụ tập đông đúc) -> Khán giả xem biểu diễn",
    "管理": "Quản 管 (bộ Trúc ⺮ ống cai quản) + Lý 理 (mài dũa ngọc) -> Quản lý, điều hành",
    "广告": "Quảng 广 (mái hiên rộng lớn truyền xa) + Cáo 告 (báo cho biết) -> Quảng cáo",
    "规定": "Quy 规 (bộ Kiến 见 thước đo vòng tròn) + Định 定 (đứng vững chắc) -> Quy định, điều lệ",
    "国际": "Quốc 国 (bờ cõi bọc ngọc) + Tế 际 (bộ Phụ 阝giao hảo các nước) -> Quốc tế",
    "过程": "Quá 过 (trải qua) + Trình 程 (bộ Hòa 禾 thước đo cây lúa lớn lên) -> Quá trình diễn biến",
    "海洋": "Hải 海 (bộ Thủy 氵biển lớn) + Dương 洋 (bộ Thủy 氵+ Dương 羊: biển khơi mênh mông) -> Đại dương bao la",
    "好客": "Hảo 好 (yêu thích) + Khách 客 (người đến chơi nhà) -> Hiếu khách, mến khách",
    "合适": "Hợp 合 (vừa vặn hòa hợp) + Thích 适 (bộ Xước 辶 vừa ý) -> Thích hợp, vừa vặn",
    "后悔": "Hậu 后 (về sau) + Hối 悔 (bộ Tâm đứng 忄ray rứt ăn năn) -> Hối hận, tiếc nuối",
    "互相": "Hỗ 互 (hai chiếc ngoặc lồng vào nhau) + Tương 相 (cùng nhau) -> Lẫn nhau, qua lại",
    "回忆": "Hồi 回 (quay trở lại) + Ức 忆 (bộ Tâm đứng 忄ký ức xưa) -> Hồi ức, nhớ lại kỷ niệm",
    "获得": "Hoạch 获 (bộ Khuyển 犭săn bắt được con mồi) + Đắc 得 (thu về được) -> Thu được, giành được",
    "基础": "Cơ 基 (bộ Thổ 土 nền móng nhà) + Sở 础 (bộ Thạch 石 chân đá tảng) -> Nền tảng, cơ sở",
    "积极": "Tích 积 (bộ Hòa 禾 lúa chất đống) + Cực 极 (vươn tới đỉnh cao) -> Tích cực, hăng hái",
    "积累": "Tích 积 (tích trữ lúa gạo) + Lũy 累 (chồng chất nhiều tầng) -> Tích lũy kinh nghiệm",
    "即使": "Tức 即 (ngồi vào bàn ăn) + Sử 使 (cho dù giả sử) -> Cho dù, dẫu cho",
    "计划": "Kế 计 (bộ Ngôn 讠tính toán) + Hạch 划 (bộ Đao 刂vạch định đường lối) -> Kế hoạch",
    "技术": "Kỹ 技 (bộ Thủ 扌tay nghề khéo) + Thuật 术 (bộ Mộc 木 phương pháp tinh xảo) -> Kỹ thuật, tay nghề",
    "继续": "Kế 继 (bộ Mịch 纟sợi tơ nối dõi) + Tục 续 (bộ Mịch 纟nối dài liên tục) -> Tiếp tục duy trì",
    "价格": "Giá 价 (bộ Nhân đứng 亻định giá) + Cách 格 (khung tiêu chuẩn) -> Giá cả hàng hóa",
    "坚持": "Kiên 坚 (bộ Thổ 土 đất nén cứng rắn) + Trì 持 (bộ Thủ 扌tay nắm giữ vững) -> Kiên trì, giữ vững",
    "减少": "Giảm 减 (bộ Thủy 冫bớt nước đi) + Thiểu 少 (ít ỏi) -> Giảm bớt, hao hụt",
    "建议": "Kiến 建 (bộ Dẫn 廴xây dựng) + Nghị 议 (bộ Ngôn 讠bàn luận lời hay) -> Góp ý, đề xuất, kiến nghị",
    "将来": "Tương 将 (bộ Thốn 寸 tay chỉ huy) + Lai 来 (sắp đến) -> Tương lai mai sau",
    "交流": "Giao 交 (chân vắt chéo gặp gỡ) + Lưu 流 (bộ Thủy 氵nước chảy thông suốt) -> Giao lưu, trao đổi",
    "交通": "Giao 交 (gặp nhau) + Thông 通 (bộ Xước 辶 thông suốt không tắc) -> Giao thông đường xá",
    "教育": "Giáo 教 (dạy dỗ đạo hiếu) + Dục 育 (người mẹ nuôi dưỡng con khôn lớn) -> Giáo dục, dạy dỗ",
    "接受": "Tiếp 接 (bộ Thủ 扌tay đón lấy) + Thọ 受 (bàn tay mở lòng nhận lấy) -> Tiếp nhận, chấp nhận",
    "节约": "Tiết 节 (bộ Trúc ⺮ đốt tre chừng mực) + Ước 约 (bộ Mịch 纟bó buộc lại) -> Tiết kiệm chi tiêu",
    "解释": "Giải 解 (bộ Giác 角 mổ xẻ) + Thích 释 (phân tích buông tỏ) -> Giải thích rõ ràng",
    "紧张": "Khẩn 紧 (bộ Mịch 纟buộc dây siết chặt) + Trương 张 (bộ Cung 弓 giương căng dây cung) -> Căng thẳng, hồi hộp",
    "精彩": "Tinh 精 (bộ Mễ 米 hạt gạo tinh tuyển) + Thải 彩 (bộ Sam 彡 sắc màu rực rỡ) -> Xuất sắc, tuyệt vời",
    "景色": "Cảnh 景 (bộ Nhật 日 mặt trời chiếu trên đình cao) + Sắc 色 (sắc thái) -> Cảnh sắc, phong cảnh",
    "竞争": "Cạnh 竞 (hai người đứng tranh tài) + Tranh 争 (tay giành lấy) -> Cạnh tranh thi đua",
    "拒绝": "Cự 拒 (bộ Thủ 扌tay đẩy ra ngoài) + Tuyệt 绝 (bộ Mịch 纟cắt đứt sợi dây) -> Cự tuyệt, từ chối",
    "距离": "Cự 距 (bộ Túc ⻊bàn chân đo bước) + Ly 离 (khoảng cách rời xa) -> Cự ly, khoảng cách",
    "考虑": "Khảo 考 (người già suy xét) + Lự 虑 (bộ Hổ 虍 + Tâm 心: trăn trở lo nghĩ) -> Cân nhắc, suy xét kỹ lưỡng"
}

BREAKDOWNS_HSK5 = {
    "爱护": "Ái 爱 (yêu thương) + Hộ 护 (bảo vệ che chở) -> Yêu quý và bảo vệ gìn giữ",
    "爱惜": "Ái 爱 (yêu) + Tích 惜 (bộ Tâm đứng 忄tiếc nuối) -> Trân quý, trân trọng",
    "爱心": "Ái 爱 (yêu thương) + Tâm 心 (trái tim) -> Tấm lòng nhân ái, lòng yêu thương",
    "安慰": "An 安 (bình an) + Úy 慰 (bộ Tâm 心 xoa dịu nỗi đau) -> An ủi, động viên",
    "安装": "An 安 (vừa vặn) + Trang 装 (bộ Y 衣 trang phục lắp ráp) -> Lắp đặt, cài đặt thiết bị",
    "把握": "Bả 把 (bàn tay cầm nắm) + Ác 握 (bộ Thủ 扌tay nắm chặt) -> Nắm bắt thời cơ, nắm chắc",
    "摆": "Bộ Thủ 扌(bàn tay) + Bãi 罢 -> Bày biện, sắp đặt đồ đạc ra bàn",
    "办理": "Biện 办 (dùng sức lực giải quyết) + Lý 理 (mài dũa sắp xếp) -> Xử lý, làm thủ tục",
    "傍晚": "Bàng 傍 (bộ Nhân đứng 亻kề bên) + Vãn 晚 (bộ Nhật 日 mặt trời lặn sau núi) -> Buổi hoàng hôn, chập tối",
    "包含": "Bao 包 (ôm lấy gói tròn) + Hàm 含 (bộ Kim 今 + Khẩu 口: ngậm trong miệng) -> Bao hàm, chứa đựng bên trong",
    "宝贵": "Bảo 宝 (bộ Miên 宀 nhà có Ngọc 玉 và Bối 贝) + Quý 贵 (tiền của chất đống) -> Quý giá, bảo bối",
    "保持": "Bảo 保 (che chở gìn giữ) + Trì 持 (bộ Thủ 扌tay nắm giữ vững) -> Duy trì, giữ vững trạng thái",
    "保存": "Bảo 保 + Tồn 存 (bộ Tử 子 + Thổ 土: còn lại nguyên vẹn) -> Lưu giữ, bảo tồn",
    "保险": "Bảo 保 (bảo vệ) + Hiểm 险 (bộ Phụ 阝vách núi hiểm trở) -> Bảo hiểm, an toàn trước rủi ro",
    "报告": "Báo 报 (tay dâng tin tức) + Cáo 告 (nói rõ ngọn ngành) -> Báo cáo, bài báo cáo",
    "悲观": "Bi 悲 (Phi 非 trái tim tan nát đau buồn) + Quan 观 (nhìn đời) -> Bi quan, nhìn đời u ám",
    "背景": "Bối 背 (bộ Nguyệt 月 lưng người) + Cảnh 景 (khung cảnh phía sau) -> Bối cảnh, xuất thân",
    "本质": "Bản 本 (gốc rễ cây) + Chất 质 (bộ Bối 贝 hai đồng tiền cân bằng bản chất) -> Bản chất cốt lõi",
    "比例": "Bỉ 比 (so sánh) + Lệ 例 (bộ Nhân đứng 亻quy lệ chuẩn) -> Tỷ lệ tương quan",
    "彼此": "Bỉ 彼 (bộ Xích 彳người bên kia) + Thử 此 (người bên này) -> Lẫn nhau, đôi bên hai người",
    "毕竟": "Tất 毕 (hoàn thành xong) + Cánh 竟 (bộ Lập 立 + Âm 音: rốt cuộc sau cùng) -> Rốt cuộc, chung quy lại",
    "避免": "Tị 避 (bộ Xước 辶 bước tránh né) + Miễn 免 (thoát khỏi nạn) -> Tránh khỏi, né tránh",
    "标志": "Tiêu 标 (cột mốc gỗ) + Chí 志 (bộ Sĩ 士 + Tâm 心: dấu hiệu ghi nhớ) -> Biểu tượng, cột mốc",
    "表面": "Biểu 表 (lộ ra bên ngoài) + Diện 面 (bề mặt) -> Bề mặt bên ngoài",
    "表明": "Biểu 表 (bày tỏ) + Minh 明 (sáng tỏ) -> Làm rõ, chứng tỏ rõ ràng",
    "采访": "Thải 采 (hái lượm thu thập) + Phóng 访 (bộ Ngôn 讠đến thăm hỏi) -> Phỏng vấn, săn tin",
    "采取": "Thải 采 (thu lượm) + Thủ 取 (bộ Nhĩ 耳 + Hựu 又: tay nắm lấy) -> Áp dụng biện pháp, lấy dùng",
    "参考": "Tham 参 (tham gia đối chiếu) + Khảo 考 (kiểm tra tra cứu) -> Tham khảo tài liệu",
    "参与": "Tham 参 (tham gia) + Dữ 与 (cùng chung tay) -> Tham gia vào, góp mặt",
    "产生": "Sản 产 (bộ Lập 立 sinh sôi nảy nở) + Sinh 生 (sinh ra) -> Sản sinh, nảy sinh ra",
    "彻底": "Triệt 彻 (bộ Xích 彳đi thông suốt từ đầu đến cuối) + Để 底 (tận đáy sâu) -> Triệt để, tận gốc rễ",
    "沉默": "Trầm 沉 (bộ Thủy 氵chìm xuống đáy) + Mặc 默 (bộ Hắc 黑 đen tối + Khuyển 犬: chó im lìm không sủa) -> Trầm mặc, im lặng",
    "称赞": "Xưng 称 (bộ Hòa 禾 cân nhắc khen ngợi) + Tán 赞 (bộ Bối 贝 thưởng tiền tán dương) -> Ca ngợi, khen ngợi hết lời",
    "成果": "Thành 成 (hoàn thành) + Quả 果 (trái ngọt) -> Thành quả ngọt ngào đạt được",
    "成熟": "Thành 成 + Thục 熟 (bộ Hỏa 灬: nấu chín, thấu hiểu) -> Chín muồi, trưởng thành",
    "承担": "Thừa 承 (hai tay nâng đỡ gánh vác) + Đam 担 (bộ Thủ 扌gánh vác) -> Gánh vác trách nhiệm, đảm đương",
    "承认": "Thừa 承 (chấp nhận nâng đỡ) + Nhận 认 (bộ Ngôn 讠thừa nhận) -> Thừa nhận, công nhận sự thật",
    "程度": "Trình 程 (thước đo lúa lớn) + Độ 度 (mức độ quy chuẩn) -> Trình độ, mức độ",
    "充满": "Sung 充 (đầy ắp sinh khí) + Mãn 满 (bộ Thủy 氵nước tràn trề) -> Tràn đầy, chứa chan",
    "创造": "Sáng 创 (bộ Đao 刂chặt vạt tiên phong) + Tạo 造 (bộ Xước 辶 làm nên điều mới) -> Sáng tạo ra cái mới",
    "词汇": "Từ 词 (bộ Ngôn 讠từ ngữ) + Hối 汇 (bộ Thủy 氵dòng sông tụ hội từ ngữ) -> Vốn từ vựng, từ vựng",
    "促进": "Xúc 促 (bộ Nhân đứng 亻bước chân thúc giục) + Tiến 进 (tiến về trước) -> Thúc đẩy tiến bộ",
    "单纯": "Đơn 单 (đơn lẻ mộc mạc) + Thuần 纯 (bộ Mịch 纟sợi tơ trắng tinh khiết) -> Đơn thuần, trong sáng",
    "待遇": "Đãi 待 (bộ Xích 彳đối đãi đón tiếp) + Ngộ 遇 (bộ Xước 辶 gặp gỡ) -> Chế độ đãi ngộ, mức lương thưởng",
    "单位": "Đơn 单 (từng khối) + Vị 位 (bộ Nhân đứng 亻vị trí làm việc) -> Cơ quan, đơn vị làm việc",
    "道德": "Đạo 道 (con đường chân chính) + Đức 德 (bộ Xích 彳+ Thập Nhất Tâm: mười bốn điều tâm hướng thiện) -> Đạo đức, phẩm hạnh",
    "登记": "Đăng 登 (bước lên ghi danh) + Ký 记 (bộ Ngôn 讠ghi sổ) -> Đăng ký vào sổ sách",
    "地位": "Địa 地 (đất đai bờ cõi) + Vị 位 (vị trí đứng) -> Địa vị xã hội, vị thế",
    "独立": "Độc 独 (bộ Khuyển 犭một mình) + Lập 立 (tự mình đứng vững trên đất) -> Độc lập, tự chủ",
    "对象": "Đối 对 (đối diện) + Tượng 象 (hình tượng con voi) -> Đối tượng hướng tới, người yêu",
    "恶劣": "Ác 恶 (Á 亚 + Tâm 心: lòng dạ xấu xa) + Liệt 劣 (bộ Thiếu 少 + Lực 力: thiếu sức yếu ớt) -> Khắc nghiệt, tồi tệ",
    "发挥": "Phát 发 (phát ra) + Huy 挥 (bộ Thủ 扌tay vung cờ chỉ huy) -> Phát huy năng lực",
    "繁荣": "Phồn 繁 (bộ Mịch 纟nhiều sợi tơ dệt hoa văn) + Vinh 荣 (bộ Thảo 艹 hoa nở vinh hoa) -> Phồn vinh, hưng thịnh",
    "反应": "Phản 反 (lật lại) + Ứng 应 (đáp lại) -> Phản ứng, hồi đáp lại",
    "范围": "Phạm 范 (bộ Thảo 艹 khuôn đúc chuẩn) + Vi 围 (bộ Vi 囗 vòng tròn bao bọc) -> Phạm vi, giới hạn",
    "方式": "Phương 方 (hướng) + Thức 式 (cung cách mẫu mực) -> Phương thức, cách thức làm",
    "方案": "Phương 方 + Án 案 (bàn giấy thảo kế sách) -> Phương án, đề án",
    "访问": "Phỏng 访 (bộ Ngôn 讠thăm hỏi) + Vấn 问 (hỏi han ân cần) -> Thăm viếng, phỏng vấn",
    "分布": "Phân 分 (chia đều) + Bố 布 (tấm vải trải rộng ra) -> Phân bố, rải rác khắp nơi",
    "分析": "Phân 分 (chia đôi) + Tích 析 (bộ Mộc 木 + Cân 斤 rìu chẻ nhỏ phân tích) -> Phân tích vấn đề",
    "贡献": "Cống 贡 (bộ Bối 贝 dâng tiền của lên vua) + Hiến 献 (bộ Khuyển 犬 dâng lễ vật quý) -> Cống hiến, đóng góp",
    "规模": "Quy 规 (thước đo chuẩn mực) + Mô 模 (bộ Mộc 木 khuôn đúc) -> Quy mô tầm cỡ",
    "核心": "Hạch 核 (bộ Mộc 木 hạt nhân bên trong quả) + Tâm 心 (trái tim trung tâm) -> Cốt lõi, hạt nhân trung tâm",
    "具备": "Cụ 具 (đầy đủ dụng cụ) + Bị 备 (sẵn sàng) -> Có đủ điều kiện, sở hữu đầy đủ",
    "联合": "Liên 联 (bộ Nhĩ 耳 tai kết nối) + Hợp 合 (hòa hợp) -> Liên kết, hợp tác liên hiệp",
    "逻辑": "La 逻 + Tập 辑 (bộ Xa 车 sách đóng gáy ngay ngắn) -> Logic, tư duy chặt chẽ",
    "满足": "Mãn 满 (nước tràn đầy) + Túc 足 (bàn chân đứng đầy đủ) -> Mãn nguyện, thỏa mãn",
    "面临": "Diện 面 (khuôn mặt) + Lâm 临 (bước đến bờ sông kề bên) -> Đối mặt, đứng trước khó khăn",
    "平均": "Bình 平 (mặt nước thăng bằng) + Quân 均 (bộ Thổ 土 chia đều đất đai) -> Bình quân, chia đều",
    "企图": "Xí 企 (bộ Nhân 人 nhón chân ngóng nhìn xa) + Đồ 图 (vẽ mưu đồ) -> Mưu toan, mưu tính",
    "企业": "Xí 企 (tập hợp con người cùng chí hướng) + Nghiệp 业 (sự nghiệp kinh doanh) -> Doanh nghiệp, xí nghiệp",
    "全面": "Toàn 全 (viên ngọc vẹn toàn) + Diện 面 (mọi mặt) -> Toàn diện, đầy đủ mọi khía cạnh",
    "设备": "Thiết 设 (bộ Ngôn 讠bày biện bố trí) + Bị 备 (sẵn sàng đồ dùng) -> Thiết bị, máy móc trang bị",
    "深刻": "Thâm 深 (bộ Thủy 氵vực nước sâu thẳm) + Khắc 刻 (khắc sâu vào đá) -> Sâu sắc, khắc sâu trong tâm trí",
    "实际": "Thực 实 (sự thật đầy đủ) + Tế 际 (chạm tới biên giới) -> Thực tế, thực tiễn",
    "首要": "Thủ 首 (cái đầu người đứng đầu) + Yếu 要 (cốt yếu nhất) -> Quan trọng hàng đầu, trước hết",
    "体现": "Thể 体 (thân thể bản chất) + Hiện 现 (hiện rõ trước mắt) -> Thể hiện rõ nét",
    "投入": "Đầu 投 (bộ Thủ 扌tay ném dồn vào) + Nhập 入 (đi vào trong) -> Đầu tư, dồn hết tâm huyết vào",
    "推迟": "Thôi 推 (bộ Thủ 扌tay đẩy lùi) + Trì 迟 (bước chân chậm chạp lùi ngày) -> Trì hoãn, hoãn lại ngày sau",
    "未来": "Vị 未 (cành cây chưa trổ lộc: chưa tới) + Lai 来 (sắp đến) -> Tương lai, những ngày sắp tới"
}

# Merge all breakdowns
ALL_BREAKDOWNS = {
    "没": "Bộ Thủy 氵(nước) + Dịch 殳 (xoáy nước) -> Chìm mất tăm dưới nước, không có"
}
ALL_BREAKDOWNS.update(BREAKDOWNS_HSK1_HSK2)
ALL_BREAKDOWNS.update(BREAKDOWNS_HSK3)
ALL_BREAKDOWNS.update(BREAKDOWNS_HSK4)
ALL_BREAKDOWNS.update(BREAKDOWNS_HSK5)

# Load existing vocabulary file
with open("app/src/main/assets/hsk_words.json", "r", encoding="utf-8") as f:
    words = json.load(f)

print(f"Total words in assets: {len(words)}")
matched_count = 0
for w in words:
    hz = w["hanzi"]
    if hz in ALL_BREAKDOWNS:
        w["breakdown"] = "🧩 " + ALL_BREAKDOWNS[hz]
        matched_count += 1
    elif not w.get("breakdown"):
        w["breakdown"] = f"🧩 Chữ {hz} -> {w.get('english', '')}"

print(f"Direct high-detail matches: {matched_count}/{len(words)}")

# Write to app assets
with open("app/src/main/assets/hsk_words.json", "w", encoding="utf-8") as f:
    json.dump(words, f, ensure_ascii=False, indent=2)

# Copy to web_preview and docs
with open("web_preview/hsk_words.json", "w", encoding="utf-8") as f:
    json.dump(words, f, ensure_ascii=False, indent=2)

with open("docs/hsk_words.json", "w", encoding="utf-8") as f:
    json.dump(words, f, ensure_ascii=False, indent=2)

print("Saved enriched hsk_words.json to app, web_preview, and docs!")
