package com.hsk.screentutor.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class IntervalAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val serviceIntent = Intent(context, VocabularyForegroundService::class.java).apply {
            action = VocabularyForegroundService.ACTION_INTERVAL_POPUP
        }
        VocabularyForegroundService.startService(context)
        context.startService(serviceIntent)
    }
}
