package com.hsk.screentutor.srs

import android.content.Context
import android.content.SharedPreferences
import com.hsk.screentutor.data.model.Vocabulary
import com.hsk.screentutor.data.repository.VocabularyRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar

class SrsManager(
    private val context: Context,
    private val repository: VocabularyRepository
) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("hsk_srs_prefs", Context.MODE_PRIVATE)

    companion object {
        const val STAGE_UNLEARNED = 0
        const val STAGE_LEARNING_TODAY = 1
        const val STAGE_REVIEW_DAY_3 = 2
        const val STAGE_REVIEW_DAY_5 = 3
        const val STAGE_REVIEW_DAY_10 = 4
        const val STAGE_MASTERED = 5

        const val PREF_CURRENT_HSK_LEVEL = "pref_current_hsk_level"
        const val PREF_DAILY_QUOTA = "pref_daily_quota"
        const val PREF_LAST_CHECKED_DAY = "pref_last_checked_day"
        const val PREF_UNLOCK_TRIGGER_ENABLED = "pref_unlock_trigger_enabled"
        const val PREF_UNLOCK_COOLDOWN_MINUTES = "pref_unlock_cooldown_minutes"
        const val PREF_INTERVAL_MINUTES = "pref_interval_minutes"
        const val PREF_AUTO_SPEAK = "pref_auto_speak"
        const val PREF_LAST_SHOWN_WORD_ID = "pref_last_shown_word_id"
    }

    var currentHskLevel: Int
        get() = prefs.getInt(PREF_CURRENT_HSK_LEVEL, 1)
        set(value) = prefs.edit().putInt(PREF_CURRENT_HSK_LEVEL, value).apply()

    var dailyQuota: Int
        get() = prefs.getInt(PREF_DAILY_QUOTA, 7)
        set(value) = prefs.edit().putInt(PREF_DAILY_QUOTA, value).apply()

    var isUnlockTriggerEnabled: Boolean
        get() = prefs.getBoolean(PREF_UNLOCK_TRIGGER_ENABLED, true)
        set(value) = prefs.edit().putBoolean(PREF_UNLOCK_TRIGGER_ENABLED, value).apply()

    var unlockCooldownMinutes: Int
        get() = prefs.getInt(PREF_UNLOCK_COOLDOWN_MINUTES, 3)
        set(value) = prefs.edit().putInt(PREF_UNLOCK_COOLDOWN_MINUTES, value).apply()

    var periodicIntervalMinutes: Int
        get() = prefs.getInt(PREF_INTERVAL_MINUTES, 30)
        set(value) = prefs.edit().putInt(PREF_INTERVAL_MINUTES, value).apply()

    var isAutoSpeakEnabled: Boolean
        get() = prefs.getBoolean(PREF_AUTO_SPEAK, true)
        set(value) = prefs.edit().putBoolean(PREF_AUTO_SPEAK, value).apply()

    /**
     * Checks if a new day has arrived.
     * Transitions yesterday's learned words into SRS review stages (Day 3, 5, 10).
     * Populates today's target words (default 7 new words).
     */
    suspend fun prepareDailyQueue(): List<Vocabulary> = withContext(Dispatchers.IO) {
        val todayKey = getTodayDayOfYear()
        val lastDay = prefs.getInt(PREF_LAST_CHECKED_DAY, -1)

        val startOfToday = getStartOfDayMillis(0)
        val endOfToday = getEndOfDayMillis(0)

        if (todayKey != lastDay) {
            // New day detected! Reset daily counters
            repository.resetDailyCounters()

            // Update words from yesterday's Stage 1 to Stage 2 (scheduled for Day 3)
            val currentStage1 = repository.getLearningToday()
            for (word in currentStage1) {
                if (word.firstLearnedDate > 0 && word.firstLearnedDate < startOfToday) {
                    word.srsStage = STAGE_REVIEW_DAY_3
                    word.nextReviewDate = getStartOfDayMillisForDate(word.firstLearnedDate, 3)
                    repository.updateWord(word)
                }
            }

            prefs.edit().putInt(PREF_LAST_CHECKED_DAY, todayKey).apply()
        }

        // Check active learning words for today
        var learningToday = repository.getLearningToday()
        val neededNew = dailyQuota - learningToday.size

        if (neededNew > 0) {
            val newWords = repository.getUnlearnedWords(currentHskLevel, neededNew)
            val currentTime = System.currentTimeMillis()
            for (word in newWords) {
                word.srsStage = STAGE_LEARNING_TODAY
                word.firstLearnedDate = currentTime
                word.nextReviewDate = 0L
                word.viewsToday = 0
                word.writesToday = 0
            }
            repository.updateWords(newWords)
            learningToday = repository.getLearningToday()
        }

        // Check if there are due review words for today (Day 3, 5, 10)
        val dueReviews = repository.getDueReviewWords(endOfToday)

        val combinedPool = ArrayList<Vocabulary>()
        combinedPool.addAll(learningToday)
        combinedPool.addAll(dueReviews)

        combinedPool
    }

    /**
     * Picks the next word to show on unlock or timer popup.
     * Prioritizes words with the fewest views today to ensure balanced intra-day repetition.
     */
    suspend fun getNextWordForPopup(): Vocabulary? = withContext(Dispatchers.IO) {
        val pool = prepareDailyQueue()
        if (pool.isEmpty()) return@withContext null

        val lastShownId = prefs.getInt(PREF_LAST_SHOWN_WORD_ID, -1)

        // Filter out the word that was shown just before if pool has multiple items
        val candidates = if (pool.size > 1) {
            pool.filter { it.id != lastShownId }
        } else {
            pool
        }

        // Pick word with minimum views today, with slight randomization for variety
        val minViews = candidates.minOf { it.viewsToday }
        val leastViewed = candidates.filter { it.viewsToday == minViews }
        val selected = leastViewed.random()

        prefs.edit().putInt(PREF_LAST_SHOWN_WORD_ID, selected.id).apply()
        selected
    }

    /**
     * Records that the user viewed this word.
     */
    suspend fun recordWordView(wordId: Int) = withContext(Dispatchers.IO) {
        val word = repository.getWordById(wordId) ?: return@withContext
        word.viewsToday += 1
        word.totalEncounters += 1
        word.lastReviewedDate = System.currentTimeMillis()
        repository.updateWord(word)
    }

    /**
     * Records that the user practiced handwriting this word on the canvas.
     */
    suspend fun recordWordWriting(wordId: Int) = withContext(Dispatchers.IO) {
        val word = repository.getWordById(wordId) ?: return@withContext
        word.writesToday += 1
        repository.updateWord(word)
    }

    /**
     * Called when user marks "Đã thuộc" or advances SRS review milestone.
     */
    suspend fun advanceSrsMilestone(wordId: Int) = withContext(Dispatchers.IO) {
        val word = repository.getWordById(wordId) ?: return@withContext
        val now = System.currentTimeMillis()
        word.lastReviewedDate = now

        when (word.srsStage) {
            STAGE_LEARNING_TODAY -> {
                // Stays in learning today so it repeats today, but next review is scheduled for Day 3
                word.nextReviewDate = getStartOfDayMillisForDate(word.firstLearnedDate, 3)
            }
            STAGE_REVIEW_DAY_3 -> {
                // Reviewed at Day 3 milestone -> Next is Day 5 milestone
                word.srsStage = STAGE_REVIEW_DAY_5
                word.nextReviewDate = getStartOfDayMillisForDate(word.firstLearnedDate, 5)
            }
            STAGE_REVIEW_DAY_5 -> {
                // Reviewed at Day 5 milestone -> Next is Day 10 milestone
                word.srsStage = STAGE_REVIEW_DAY_10
                word.nextReviewDate = getStartOfDayMillisForDate(word.firstLearnedDate, 10)
            }
            STAGE_REVIEW_DAY_10 -> {
                // Reviewed at Day 10 milestone -> Mastered!
                word.srsStage = STAGE_MASTERED
                word.nextReviewDate = 0L
            }
        }
        repository.updateWord(word)
    }

    private fun getTodayDayOfYear(): Int {
        val calendar = Calendar.getInstance()
        return calendar.get(Calendar.YEAR) * 1000 + calendar.get(Calendar.DAY_OF_YEAR)
    }

    private fun getStartOfDayMillis(offsetDays: Int): Long {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, offsetDays)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    private fun getEndOfDayMillis(offsetDays: Int): Long {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, offsetDays)
        cal.set(Calendar.HOUR_OF_DAY, 23)
        cal.set(Calendar.MINUTE, 59)
        cal.set(Calendar.SECOND, 59)
        cal.set(Calendar.MILLISECOND, 999)
        return cal.timeInMillis
    }

    private fun getStartOfDayMillisForDate(baseTime: Long, offsetDays: Int): Long {
        val cal = Calendar.getInstance()
        cal.timeInMillis = baseTime
        cal.add(Calendar.DAY_OF_YEAR, offsetDays)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }
}
