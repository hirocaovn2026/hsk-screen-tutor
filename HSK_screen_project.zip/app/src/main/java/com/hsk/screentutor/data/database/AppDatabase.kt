package com.hsk.screentutor.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.hsk.screentutor.data.dao.VocabularyDao
import com.hsk.screentutor.data.model.Vocabulary
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.InputStreamReader

@Database(entities = [Vocabulary::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {

    abstract fun vocabularyDao(): VocabularyDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "hsk_vocabulary_database"
                )
                .fallbackToDestructiveMigration()
                .addCallback(DatabasePrepopulateCallback(context.applicationContext))
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class DatabasePrepopulateCallback(
        private val context: Context
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            CoroutineScope(Dispatchers.IO).launch {
                prepopulateDatabase(context)
            }
        }

        override fun onOpen(db: SupportSQLiteDatabase) {
            super.onOpen(db)
            CoroutineScope(Dispatchers.IO).launch {
                prepopulateDatabase(context)
            }
        }

        private suspend fun prepopulateDatabase(context: Context) {
            try {
                val assetManager = context.assets
                val inputStream = assetManager.open("hsk_words.json")
                val reader = InputStreamReader(inputStream, "UTF-8")
                val wordListType = object : TypeToken<List<Vocabulary>>() {}.type
                val words: List<Vocabulary> = Gson().fromJson(reader, wordListType)
                reader.close()

                val dao = getDatabase(context).vocabularyDao()
                dao.insertAll(words)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
