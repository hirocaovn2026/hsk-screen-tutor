package com.hsk.screentutor.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.hsk.screentutor.data.model.Vocabulary
import com.hsk.screentutor.databinding.ItemWordBinding
import com.hsk.screentutor.srs.SrsManager

class WordAdapter(
    private val onSpeakClick: (Vocabulary) -> Unit,
    private val onItemClick: (Vocabulary) -> Unit
) : ListAdapter<Vocabulary, WordAdapter.WordViewHolder>(DiffCallback) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WordViewHolder {
        val binding = ItemWordBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return WordViewHolder(binding)
    }

    override fun onBindViewHolder(holder: WordViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class WordViewHolder(private val binding: ItemWordBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(word: Vocabulary) {
            binding.itemHanzi.text = word.hanzi
            binding.itemPinyin.text = word.pinyin
            binding.itemEnglish.text = "${word.english} (${word.partOfSpeech})"

            val stageName = when (word.srsStage) {
                SrsManager.STAGE_LEARNING_TODAY -> "Ngày 1 (Lặp lại)"
                SrsManager.STAGE_REVIEW_DAY_3 -> "Ôn Ngày 3"
                SrsManager.STAGE_REVIEW_DAY_5 -> "Ôn Ngày 5"
                SrsManager.STAGE_REVIEW_DAY_10 -> "Ôn Ngày 10"
                SrsManager.STAGE_MASTERED -> "Đã thuộc"
                else -> "Chưa học"
            }
            binding.itemStageBadge.text = stageName
            binding.itemEncounters.text = "Lặp lại hôm nay: ${word.viewsToday} lần | Viết tay: ${word.writesToday} lần"

            binding.itemBtnSpeak.setOnClickListener {
                onSpeakClick(word)
            }

            binding.root.setOnClickListener {
                onItemClick(word)
            }
        }
    }

    companion object DiffCallback : DiffUtil.ItemCallback<Vocabulary>() {
        override fun areItemsTheSame(oldItem: Vocabulary, newItem: Vocabulary): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Vocabulary, newItem: Vocabulary): Boolean {
            return oldItem == newItem
        }
    }
}
