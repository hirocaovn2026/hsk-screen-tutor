package com.hsk.screentutor.data.repository

import com.hsk.screentutor.data.dao.VocabularyDao
import com.hsk.screentutor.data.model.Vocabulary
import kotlinx.coroutines.flow.Flow

class VocabularyRepository(private val vocabularyDao: VocabularyDao) {

    fun getWordsByLevel(level: Int): Flow<List<Vocabulary>> =
        vocabularyDao.getWordsByLevel(level)

    suspend fun getWordsByLevelDirect(level: Int): List<Vocabulary> =
        vocabularyDao.getWordsByLevelDirect(level)

    suspend fun getWordById(id: Int): Vocabulary? =
        vocabularyDao.getWordById(id)

    fun getLearningTodayFlow(): Flow<List<Vocabulary>> =
        vocabularyDao.getLearningTodayFlow()

    suspend fun getLearningToday(): List<Vocabulary> =
        vocabularyDao.getLearningToday()

    suspend fun getDueReviewWords(endOfToday: Long): List<Vocabulary> =
        vocabularyDao.getDueReviewWords(endOfToday)

    suspend fun getUnlearnedWords(level: Int, limit: Int): List<Vocabulary> =
        vocabularyDao.getUnlearnedWords(level, limit)

    suspend fun updateWord(word: Vocabulary) =
        vocabularyDao.updateWord(word)

    suspend fun updateWords(words: List<Vocabulary>) =
        vocabularyDao.updateWords(words)

    suspend fun resetDailyCounters() =
        vocabularyDao.resetDailyCounters()

    suspend fun getLearnedCountByLevel(level: Int): Int =
        vocabularyDao.getLearnedCountByLevel(level)

    suspend fun getTotalCountByLevel(level: Int): Int =
        vocabularyDao.getTotalCountByLevel(level)
}
