package com.hsk.screentutor.data.dao

import androidx.room.*
import com.hsk.screentutor.data.model.Vocabulary
import kotlinx.coroutines.flow.Flow

@Dao
interface VocabularyDao {

    @Query("SELECT * FROM vocabulary WHERE level = :level ORDER BY id ASC")
    fun getWordsByLevel(level: Int): Flow<List<Vocabulary>>

    @Query("SELECT * FROM vocabulary WHERE level = :level ORDER BY id ASC")
    suspend fun getWordsByLevelDirect(level: Int): List<Vocabulary>

    @Query("SELECT * FROM vocabulary WHERE id = :id LIMIT 1")
    suspend fun getWordById(id: Int): Vocabulary?

    // Words currently in today's active learning pool (Stage 1)
    @Query("SELECT * FROM vocabulary WHERE srsStage = 1")
    fun getLearningTodayFlow(): Flow<List<Vocabulary>>

    @Query("SELECT * FROM vocabulary WHERE srsStage = 1")
    suspend fun getLearningToday(): List<Vocabulary>

    // Words due for spaced review today (Stage 2, 3, 4 with nextReviewDate <= endOfToday)
    @Query("SELECT * FROM vocabulary WHERE srsStage IN (2, 3, 4) AND nextReviewDate <= :endOfToday")
    suspend fun getDueReviewWords(endOfToday: Long): List<Vocabulary>

    // Pull unlearned words for current level
    @Query("SELECT * FROM vocabulary WHERE srsStage = 0 AND level = :level ORDER BY id ASC LIMIT :limit")
    suspend fun getUnlearnedWords(level: Int, limit: Int): List<Vocabulary>

    // Total count of words learned/mastered
    @Query("SELECT COUNT(*) FROM vocabulary WHERE srsStage > 0 AND level = :level")
    suspend fun getLearnedCountByLevel(level: Int): Int

    @Query("SELECT COUNT(*) FROM vocabulary WHERE level = :level")
    suspend fun getTotalCountByLevel(level: Int): Int

    // Reset daily counters for all words
    @Query("UPDATE vocabulary SET viewsToday = 0, writesToday = 0")
    suspend fun resetDailyCounters()

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(words: List<Vocabulary>)

    @Update
    suspend fun updateWord(word: Vocabulary)

    @Update
    suspend fun updateWords(words: List<Vocabulary>)
}
