package com.hsk.screentutor

import android.app.Application
import com.hsk.screentutor.data.database.AppDatabase
import com.hsk.screentutor.data.repository.VocabularyRepository
import com.hsk.screentutor.service.VocabularyForegroundService
import com.hsk.screentutor.srs.SrsManager

class HskApplication : Application() {

    val database by lazy { AppDatabase.getDatabase(this) }
    val repository by lazy { VocabularyRepository(database.vocabularyDao()) }
    val srsManager by lazy { SrsManager(this, repository) }

    override fun onCreate() {
        super.onCreate()
        // Auto-start foreground service if enabled
        VocabularyForegroundService.startService(this)
    }
}
