package com.hsk.screentutor.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "vocabulary")
data class Vocabulary(
    @PrimaryKey
    val id: Int,
    val level: Int,                   // 1 for HSK 1, 2 for HSK 2, etc.
    val hanzi: String,                 // Chinese character(s)
    val pinyin: String,                // Pinyin with tone marks
    val english: String,               // English translation / explanation
    val partOfSpeech: String,          // noun, verb, adj, phrase, etc.
    val exampleCn: String,             // Example sentence in Chinese
    val examplePinyin: String,         // Pinyin of example sentence
    val exampleEn: String,             // English translation of example sentence
    val breakdown: String = "",        // Radical & component etymology / mnemonics (Chiết tự / Cấu tạo từ)

    // SRS Learning State
    // 0: UNLEARNED
    // 1: LEARNING_TODAY (in today's active pool, repeats all day on unlocks & intervals)
    // 2: REVIEW_DAY_3 (scheduled for review 3 days after day 1)
    // 3: REVIEW_DAY_5 (scheduled for review 5 days after day 1)
    // 4: REVIEW_DAY_10 (scheduled for review 10 days after day 1)
    // 5: MASTERED (retained in long-term memory)
    var srsStage: Int = 0,
    var firstLearnedDate: Long = 0L,   // Epoch millis when first added to today's learning
    var nextReviewDate: Long = 0L,     // Epoch millis for scheduled review date (00:00:00)
    var lastReviewedDate: Long = 0L,   // Epoch millis of most recent encounter

    // Intra-day counters
    var viewsToday: Int = 0,           // Times shown today on unlock/interval
    var writesToday: Int = 0,          // Times user practiced writing on canvas today
    var totalEncounters: Int = 0       // Lifetime views
)
