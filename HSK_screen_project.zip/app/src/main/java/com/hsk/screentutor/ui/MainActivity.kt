package com.hsk.screentutor.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.hsk.screentutor.HskApplication
import com.hsk.screentutor.R
import com.hsk.screentutor.data.model.Vocabulary
import com.hsk.screentutor.databinding.ActivityMainBinding
import com.hsk.screentutor.service.VocabularyForegroundService
import com.hsk.screentutor.srs.SrsManager
import com.hsk.screentutor.util.SoundManager
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var srsManager: SrsManager
    private var soundManager: SoundManager? = null
    private lateinit var wordAdapter: WordAdapter

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (!isGranted) {
            Toast.makeText(this, "Vui lòng cấp quyền thông báo để nhận nhắc nhở từ vựng", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val app = application as HskApplication
        srsManager = app.srsManager
        soundManager = SoundManager(this)

        setupRecyclerView()
        setupListeners()
        requestPermissionsIfNeeded()
    }

    override fun onResume() {
        super.onResume()
        checkPermissionCards()
        loadDashboardData()
    }

    private fun setupRecyclerView() {
        wordAdapter = WordAdapter(
            onSpeakClick = { word ->
                soundManager?.speak(word.hanzi)
            },
            onItemClick = { word ->
                soundManager?.speak(word.hanzi)
            }
        )
        binding.rvTodayWords.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = wordAdapter
        }
    }

    private fun setupListeners() {
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        binding.btnViewAllWords.setOnClickListener {
            startActivity(Intent(this, WordListActivity::class.java))
        }

        binding.btnTestPopup.setOnClickListener {
            startActivity(Intent(this, PopupActivity::class.java))
        }

        binding.switchService.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                VocabularyForegroundService.startService(this)
                binding.tvServiceTitle.text = getString(R.string.service_active)
            } else {
                VocabularyForegroundService.stopService(this)
                binding.tvServiceTitle.text = getString(R.string.service_inactive)
            }
        }

        binding.btnGrantOverlay.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            }
        }

        binding.btnIgnoreBattery.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            }
        }
    }

    private fun checkPermissionCards() {
        // Overlay permission check
        val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }
        binding.cardPermissionOverlay.visibility = if (canDrawOverlays) View.GONE else View.VISIBLE

        // Battery optimization check
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val isIgnoringBattery = pm.isIgnoringBatteryOptimizations(packageName)
            binding.cardBatteryOptimization.visibility = if (isIgnoringBattery) View.GONE else View.VISIBLE
        } else {
            binding.cardBatteryOptimization.visibility = View.GONE
        }
    }

    private fun requestPermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun loadDashboardData() {
        binding.tvCurrentLevelBadge.text = "HSK ${srsManager.currentHskLevel}"

        lifecycleScope.launch {
            val todayWords = srsManager.prepareDailyQueue()
            wordAdapter.submitList(todayWords)

            val newCount = todayWords.count { it.srsStage == SrsManager.STAGE_LEARNING_TODAY }
            val reviewCount = todayWords.count { it.srsStage in SrsManager.STAGE_REVIEW_DAY_3..SrsManager.STAGE_REVIEW_DAY_10 }
            val totalEncounters = todayWords.sumOf { it.viewsToday }

            binding.tvNewWordsCount.text = newCount.toString()
            binding.tvReviewWordsCount.text = reviewCount.toString()
            binding.tvTotalEncounters.text = totalEncounters.toString()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        soundManager?.release()
        soundManager = null
    }
}
