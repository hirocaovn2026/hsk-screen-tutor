package com.hsk.screentutor.ui

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import androidx.core.content.ContextCompat
import com.hsk.screentutor.R

class WritingCanvasView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val userPath = Path()
    private var lastX = 0f
    private var lastY = 0f
    private var strokeCount = 0

    private var ghostText: String = ""
    private var showGhost: Boolean = true

    // Paint for calligraphy ink stroke - rich, bold brush width for 260dp canvas
    private val strokePaint = Paint().apply {
        isAntiAlias = true
        isDither = true
        color = Color.parseColor("#1A1A1A")
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 20f
    }

    // Paint for Tianzige grid guidelines (red dashed)
    private val gridPaint = Paint().apply {
        isAntiAlias = true
        color = ContextCompat.getColor(context, R.color.tianzige_grid)
        style = Paint.Style.STROKE
        strokeWidth = 3f
        pathEffect = DashPathEffect(floatArrayOf(12f, 10f), 0f)
    }

    // Paint for outer border
    private val borderPaint = Paint().apply {
        isAntiAlias = true
        color = ContextCompat.getColor(context, R.color.tianzige_grid)
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }

    // Paint for ghost character (faint reference for tracing)
    private val ghostPaint = Paint().apply {
        isAntiAlias = true
        color = Color.parseColor("#D5D8DC")
        style = Paint.Style.FILL
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
    }

    var onStrokeDrawnListener: (() -> Unit)? = null

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()

        if (w <= 0 || h <= 0) return

        // 1. Draw outer border
        canvas.drawRect(2f, 2f, w - 2f, h - 2f, borderPaint)

        // 2. Draw Tianzige / Mige guidelines
        // Horizontal midline
        canvas.drawLine(0f, h / 2f, w, h / 2f, gridPaint)
        // Vertical midline
        canvas.drawLine(w / 2f, 0f, w / 2f, h, gridPaint)
        // Diagonal lines (Mige)
        canvas.drawLine(0f, 0f, w, h, gridPaint)
        canvas.drawLine(0f, h, w, 0f, gridPaint)

        // 3. Draw ghost character if enabled (Single character centered)
        if (showGhost && ghostText.isNotEmpty()) {
            ghostPaint.textSize = h * 0.74f
            val fontMetrics = ghostPaint.fontMetrics
            val baseline = (h - fontMetrics.bottom + fontMetrics.top) / 2f - fontMetrics.top
            canvas.drawText(ghostText, w / 2f, baseline, ghostPaint)
        }

        // 4. Draw user's ink path
        canvas.drawPath(userPath, strokePaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                userPath.moveTo(x, y)
                lastX = x
                lastY = y
                strokeCount++
                onStrokeDrawnListener?.invoke()
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = Math.abs(x - lastX)
                val dy = Math.abs(y - lastY)
                if (dx >= 3f || dy >= 3f) {
                    userPath.quadTo(lastX, lastY, (x + lastX) / 2f, (y + lastY) / 2f)
                    lastX = x
                    lastY = y
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                userPath.lineTo(lastX, lastY)
                invalidate()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    fun setGhostCharacter(char: String) {
        this.ghostText = char
        invalidate()
    }

    fun toggleGhost(): Boolean {
        this.showGhost = !this.showGhost
        invalidate()
        return this.showGhost
    }

    fun setGhostVisible(visible: Boolean) {
        this.showGhost = visible
        invalidate()
    }

    fun clear() {
        userPath.reset()
        strokeCount = 0
        invalidate()
    }

    fun hasDrawn(): Boolean = strokeCount > 0
}
