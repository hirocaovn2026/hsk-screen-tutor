package com.hsk.screentutor.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.tabs.TabLayout
import com.hsk.screentutor.HskApplication
import com.hsk.screentutor.data.repository.VocabularyRepository
import com.hsk.screentutor.databinding.ActivityWordListBinding
import com.hsk.screentutor.util.SoundManager
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class WordListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityWordListBinding
    private lateinit var repository: VocabularyRepository
    private var soundManager: SoundManager? = null
    private lateinit var wordAdapter: WordAdapter
    private var selectedLevel = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWordListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val app = application as HskApplication
        repository = app.repository
        soundManager = SoundManager(this)

        setupToolbar()
        setupRecyclerView()
        setupTabs()
        loadWordsForLevel(selectedLevel)
    }

    private fun setupToolbar() {
        binding.toolbarWordList.setNavigationOnClickListener {
            finish()
        }
    }

    private fun setupRecyclerView() {
        wordAdapter = WordAdapter(
            onSpeakClick = { word ->
                soundManager?.speak(word.hanzi)
            },
            onItemClick = { word ->
                soundManager?.speak(word.hanzi)
            }
        )
        binding.rvAllWords.apply {
            layoutManager = LinearLayoutManager(this@WordListActivity)
            adapter = wordAdapter
        }
    }

    private fun setupTabs() {
        binding.tabLayoutLevels.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                selectedLevel = (tab?.position ?: 0) + 1
                loadWordsForLevel(selectedLevel)
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }

    private fun loadWordsForLevel(level: Int) {
        lifecycleScope.launch {
            repository.getWordsByLevel(level).collectLatest { words ->
                wordAdapter.submitList(words)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        soundManager?.release()
        soundManager = null
    }
}
