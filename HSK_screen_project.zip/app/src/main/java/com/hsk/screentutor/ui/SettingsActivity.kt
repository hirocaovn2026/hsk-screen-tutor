package com.hsk.screentutor.ui

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import com.hsk.screentutor.HskApplication
import com.hsk.screentutor.databinding.ActivitySettingsBinding
import com.hsk.screentutor.srs.SrsManager

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var srsManager: SrsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val app = application as HskApplication
        srsManager = app.srsManager

        setupToolbar()
        setupSpinners()
        setupSwitches()
    }

    private fun setupToolbar() {
        binding.toolbarSettings.setNavigationOnClickListener {
            finish()
        }
    }

    private fun setupSpinners() {
        // HSK Level Spinner
        val levelOptions = listOf("HSK 1 (Cơ bản)", "HSK 2", "HSK 3", "HSK 4", "HSK 5")
        val levelAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, levelOptions)
        binding.spnHskLevel.adapter = levelAdapter
        binding.spnHskLevel.setSelection((srsManager.currentHskLevel - 1).coerceIn(0, 4))
        binding.spnHskLevel.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                srsManager.currentHskLevel = position + 1
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        // Daily Quota Spinner
        val quotaOptions = listOf("5 từ", "7 từ (Khuyên dùng)", "10 từ", "15 từ")
        val quotaValues = listOf(5, 7, 10, 15)
        val quotaAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, quotaOptions)
        binding.spnDailyQuota.adapter = quotaAdapter
        val currentQuotaIndex = quotaValues.indexOf(srsManager.dailyQuota).let { if (it >= 0) it else 1 }
        binding.spnDailyQuota.setSelection(currentQuotaIndex)
        binding.spnDailyQuota.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                srsManager.dailyQuota = quotaValues[position]
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        // Unlock Cooldown Spinner
        val cooldownOptions = listOf("Ngay lập tức (0 phút)", "1 phút", "3 phút (Mặc định)", "5 phút", "10 phút")
        val cooldownValues = listOf(0, 1, 3, 5, 10)
        val cooldownAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, cooldownOptions)
        binding.spnCooldown.adapter = cooldownAdapter
        val currentCooldownIndex = cooldownValues.indexOf(srsManager.unlockCooldownMinutes).let { if (it >= 0) it else 2 }
        binding.spnCooldown.setSelection(currentCooldownIndex)
        binding.spnCooldown.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                srsManager.unlockCooldownMinutes = cooldownValues[position]
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        // Periodic Interval Spinner
        val intervalOptions = listOf("Tắt chu kỳ", "15 phút", "30 phút (Mặc định)", "45 phút", "60 phút (1 giờ)", "120 phút (2 giờ)")
        val intervalValues = listOf(0, 15, 30, 45, 60, 120)
        val intervalAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, intervalOptions)
        binding.spnPeriodicInterval.adapter = intervalAdapter
        val currentIntervalIndex = intervalValues.indexOf(srsManager.periodicIntervalMinutes).let { if (it >= 0) it else 2 }
        binding.spnPeriodicInterval.setSelection(currentIntervalIndex)
        binding.spnPeriodicInterval.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                srsManager.periodicIntervalMinutes = intervalValues[position]
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun setupSwitches() {
        binding.switchUnlockTrigger.isChecked = srsManager.isUnlockTriggerEnabled
        binding.switchUnlockTrigger.setOnCheckedChangeListener { _, isChecked ->
            srsManager.isUnlockTriggerEnabled = isChecked
        }

        binding.switchAutoSpeak.isChecked = srsManager.isAutoSpeakEnabled
        binding.switchAutoSpeak.setOnCheckedChangeListener { _, isChecked ->
            srsManager.isAutoSpeakEnabled = isChecked
        }
    }
}
