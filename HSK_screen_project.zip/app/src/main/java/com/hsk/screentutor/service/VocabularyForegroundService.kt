package com.hsk.screentutor.service

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.provider.Settings
import com.hsk.screentutor.HskApplication
import com.hsk.screentutor.srs.SrsManager
import com.hsk.screentutor.ui.PopupActivity
import com.hsk.screentutor.util.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class VocabularyForegroundService : Service() {

    private val serviceJob = Job()
    private val serviceScope = CoroutineScope(Dispatchers.Main + serviceJob)

    private lateinit var notificationHelper: NotificationHelper
    private lateinit var srsManager: SrsManager
    private var screenUnlockReceiver: BroadcastReceiver? = null
    private var lastUnlockTriggerTime = 0L

    companion object {
        const val ACTION_START_SERVICE = "com.hsk.screentutor.action.START"
        const val ACTION_STOP_SERVICE = "com.hsk.screentutor.action.STOP"
        const val ACTION_INTERVAL_POPUP = "com.hsk.screentutor.action.INTERVAL_POPUP"

        fun startService(context: Context) {
            val intent = Intent(context, VocabularyForegroundService::class.java).apply {
                action = ACTION_START_SERVICE
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, VocabularyForegroundService::class.java).apply {
                action = ACTION_STOP_SERVICE
            }
            context.startService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val app = application as HskApplication
        srsManager = app.srsManager
        notificationHelper = NotificationHelper(this)

        startForeground(
            NotificationHelper.NOTIFICATION_SERVICE_ID,
            notificationHelper.buildForegroundNotification(srsManager.dailyQuota)
        )

        registerUnlockReceiver()
        scheduleNextPeriodicInterval()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_SERVICE -> {
                stopForeground(true)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_INTERVAL_POPUP -> {
                handlePeriodicIntervalTrigger()
                scheduleNextPeriodicInterval()
            }
            else -> {
                scheduleNextPeriodicInterval()
            }
        }
        return START_STICKY
    }

    private fun registerUnlockReceiver() {
        if (screenUnlockReceiver != null) return

        screenUnlockReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action == Intent.ACTION_USER_PRESENT) {
                    handleUserUnlockedDevice()
                }
            }
        }

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        registerReceiver(screenUnlockReceiver, filter)
    }

    private fun unregisterUnlockReceiver() {
        screenUnlockReceiver?.let {
            try {
                unregisterReceiver(it)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            screenUnlockReceiver = null
        }
    }

    private fun handleUserUnlockedDevice() {
        if (!srsManager.isUnlockTriggerEnabled) return

        val now = SystemClock.elapsedRealtime()
        val cooldownMillis = srsManager.unlockCooldownMinutes * 60 * 1000L

        // Check if cooldown has passed since last popup
        if (now - lastUnlockTriggerTime < cooldownMillis) {
            return
        }
        lastUnlockTriggerTime = now

        triggerPopupScreen()
    }

    private fun handlePeriodicIntervalTrigger() {
        triggerPopupScreen()
    }

    private fun triggerPopupScreen() {
        serviceScope.launch {
            // Check if can draw overlays or direct launch
            val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Settings.canDrawOverlays(this@VocabularyForegroundService)
            } else {
                true
            }

            if (canDrawOverlays) {
                // Directly launch PopupActivity
                val popupIntent = Intent(this@VocabularyForegroundService, PopupActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP or
                            Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
                }
                startActivity(popupIntent)
            } else {
                // If overlay permission not granted yet, show high-priority Heads-up Notification with FullScreenIntent
                val word = srsManager.getNextWordForPopup()
                if (word != null) {
                    notificationHelper.showHeadsUpNotification(word.hanzi, word.pinyin, word.english)
                }
            }
        }
    }

    private fun scheduleNextPeriodicInterval() {
        val intervalMins = srsManager.periodicIntervalMinutes
        if (intervalMins <= 0) return

        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, IntervalAlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            this,
            100,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val triggerTime = System.currentTimeMillis() + (intervalMins * 60 * 1000L)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                triggerTime,
                pendingIntent
            )
        } else {
            alarmManager.setExact(
                AlarmManager.RTC_WAKEUP,
                triggerTime,
                pendingIntent
            )
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterUnlockReceiver()
        serviceJob.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
