package com.hsk.screentutor.ui

import android.annotation.SuppressLint
import android.app.KeyguardManager
import android.content.Context
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.chip.Chip
import com.hsk.screentutor.HskApplication
import com.hsk.screentutor.data.model.Vocabulary
import com.hsk.screentutor.databinding.ActivityPopupBinding
import com.hsk.screentutor.srs.SrsManager
import com.hsk.screentutor.util.SoundManager
import kotlinx.coroutines.launch

class PopupActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPopupBinding
    private lateinit var srsManager: SrsManager
    private var soundManager: SoundManager? = null
    private var currentWord: Vocabulary? = null
    private var currentCharIndex: Int = 0
    private var isWebViewReady: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setupLockscreenDisplay()

        binding = ActivityPopupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val app = application as HskApplication
        srsManager = app.srsManager
        soundManager = SoundManager(this)

        setupWebView()
        setupListeners()
        loadNextWord()
    }

    private fun setupLockscreenDisplay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            keyguardManager.requestDismissKeyguard(this, null)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                        WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        binding.webStrokeDemo.apply {
            settings.javaScriptEnabled = true
            settings.allowFileAccess = true
            settings.domStorageEnabled = true
            setBackgroundColor(Color.TRANSPARENT)
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    isWebViewReady = true
                    updateDemoCharacter(false)
                }
            }
            loadUrl("file:///android_asset/writer.html")
        }
    }

    private fun setupListeners() {
        // "Viết mẫu" Button: Switch to demo animation or replay it
        binding.btnDemoStroke.setOnClickListener {
            showDemoMode()
        }

        // "Tự viết" Button: Switch to freehand writing canvas
        binding.btnPracticeWrite.setOnClickListener {
            showPracticeMode()
        }

        binding.btnClearCanvas.setOnClickListener {
            binding.writingCanvas.clear()
        }

        binding.btnToggleGhost.setOnClickListener {
            val isGhostOn = binding.writingCanvas.toggleGhost()
            binding.btnToggleGhost.text = if (isGhostOn) "Ẩn mẫu" else "Hiện mẫu"
        }

        binding.btnNextChar.setOnClickListener {
            currentWord?.let { word ->
                val chars = word.hanzi.toCharArray()
                if (chars.isNotEmpty()) {
                    currentCharIndex = (currentCharIndex + 1) % chars.size
                    selectCharacterAt(currentCharIndex, chars)
                }
            }
        }

        binding.writingCanvas.onStrokeDrawnListener = {
            currentWord?.let { word ->
                lifecycleScope.launch {
                    srsManager.recordWordWriting(word.id)
                }
            }
        }

        binding.btnSpeakWord.setOnClickListener {
            currentWord?.let { word ->
                soundManager?.speak(word.hanzi)
            }
        }

        binding.btnSpeakExample.setOnClickListener {
            currentWord?.let { word ->
                soundManager?.speak(word.exampleCn)
            }
        }

        binding.btnNext.setOnClickListener {
            currentWord?.let { word ->
                lifecycleScope.launch {
                    srsManager.advanceSrsMilestone(word.id)
                    finish()
                }
            } ?: finish()
        }

        binding.btnSnooze.setOnClickListener {
            finish()
        }
    }

    private fun showDemoMode() {
        binding.webStrokeDemo.visibility = View.VISIBLE
        binding.writingCanvas.visibility = View.GONE
        updateDemoCharacter(true)
    }

    private fun showPracticeMode() {
        binding.webStrokeDemo.visibility = View.GONE
        binding.writingCanvas.visibility = View.VISIBLE
    }

    private fun updateDemoCharacter(autoAnimate: Boolean) {
        if (!isWebViewReady) return
        currentWord?.let { word ->
            val chars = word.hanzi.toCharArray()
            if (currentCharIndex in chars.indices) {
                val charStr = chars[currentCharIndex].toString()
                binding.webStrokeDemo.evaluateJavascript("setCharacter('$charStr', $autoAnimate);", null)
            }
        }
    }

    private fun loadNextWord() {
        lifecycleScope.launch {
            val word = srsManager.getNextWordForPopup()
            if (word == null) {
                finish()
                return@launch
            }
            currentWord = word
            currentCharIndex = 0
            srsManager.recordWordView(word.id)

            // Bind word data
            binding.tvHskLevel.text = "HSK ${word.level}"
            binding.tvHanzi.text = word.hanzi
            binding.tvPinyin.text = word.pinyin
            binding.tvEnglish.text = "${word.english} (${word.partOfSpeech})"

            val stageText = when (word.srsStage) {
                SrsManager.STAGE_LEARNING_TODAY -> "Ngày 1 (Đang lặp lại)"
                SrsManager.STAGE_REVIEW_DAY_3 -> "Ôn tập Ngày 3"
                SrsManager.STAGE_REVIEW_DAY_5 -> "Ôn tập Ngày 5"
                SrsManager.STAGE_REVIEW_DAY_10 -> "Ôn tập Ngày 10"
                else -> "Ngày 1"
            }
            binding.tvSrsProgress.text = "Lần học hôm nay: ${word.viewsToday + 1} | $stageText"

            // Setup multi-character tabs
            val chars = word.hanzi.toCharArray()
            if (chars.size > 1) {
                binding.scrollCharacterTabs.visibility = View.VISIBLE
                binding.btnNextChar.visibility = View.VISIBLE
                binding.chipGroupCharacters.removeAllViews()

                for (i in chars.indices) {
                    val chip = Chip(this@PopupActivity).apply {
                        text = "Chữ ${i + 1}: ${chars[i]}"
                        isCheckable = true
                        isChecked = (i == 0)
                        setOnClickListener {
                            currentCharIndex = i
                            selectCharacterAt(i, chars)
                        }
                    }
                    binding.chipGroupCharacters.addView(chip)
                }
            } else {
                binding.scrollCharacterTabs.visibility = View.GONE
                binding.btnNextChar.visibility = View.GONE
            }

            // Set initial ghost character on canvas for finger tracing
            selectCharacterAt(0, chars)

            // Bind example sentence
            binding.tvExampleCn.text = word.exampleCn
            binding.tvExamplePinyin.text = word.examplePinyin
            binding.tvExampleEn.text = word.exampleEn

            // Auto-speak if enabled
            if (srsManager.isAutoSpeakEnabled) {
                binding.root.postDelayed({
                    soundManager?.speak(word.hanzi)
                }, 400)
            }
        }
    }

    private fun selectCharacterAt(index: Int, chars: CharArray) {
        if (chars.isNotEmpty() && index in chars.indices) {
            val charStr = chars[index].toString()
            binding.writingCanvas.setGhostCharacter(charStr)
            binding.writingCanvas.clear()

            if (isWebViewReady) {
                val shouldAnimate = (binding.webStrokeDemo.visibility == View.VISIBLE)
                binding.webStrokeDemo.evaluateJavascript("setCharacter('$charStr', $shouldAnimate);", null)
            }

            // Update chip selection if multi-character
            if (chars.size > 1) {
                for (i in 0 until binding.chipGroupCharacters.childCount) {
                    val child = binding.chipGroupCharacters.getChildAt(i) as? Chip
                    child?.isChecked = (i == index)
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        soundManager?.release()
        soundManager = null
    }
}
