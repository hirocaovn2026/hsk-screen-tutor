# -*- coding: utf-8 -*-
import json
import os

words = []

def add_w(wid, level, hanzi, pinyin, english, pos, ex_cn, ex_py, ex_en):
    words.append({
        "id": wid,
        "level": level,
        "hanzi": hanzi,
        "pinyin": pinyin,
        "english": english,
        "partOfSpeech": pos,
        "exampleCn": ex_cn,
        "examplePinyin": ex_py,
        "exampleEn": ex_en
    })

# Load existing words if available to preserve HSK 1
if os.path.exists("app/src/main/assets/hsk_words.json"):
    with open("app/src/main/assets/hsk_words.json", "r", encoding="utf-8") as f:
        existing = json.load(f)
        for w in existing:
            if w["level"] == 1:
                words.append(w)

print(f"Preserved {len(words)} HSK 1 words.")
