import json
import os

hsk_data = [
    # --- HSK 1 ---
    {
        "id": 1001, "level": 1, "hanzi": "爱", "pinyin": "ài", "english": "to love; affection", "partOfSpeech": "verb/noun",
        "exampleCn": "我爱学汉语。", "examplePinyin": "Wǒ ài xué Hànyǔ.", "exampleEn": "I love learning Chinese."
    },
    {
        "id": 1002, "level": 1, "hanzi": "八", "pinyin": "bā", "english": "eight", "partOfSpeech": "numeral",
        "exampleCn": "他有八本书。", "examplePinyin": "Tā yǒu bā běn shū.", "exampleEn": "He has eight books."
    },
    {
        "id": 1003, "level": 1, "hanzi": "爸爸", "pinyin": "bàba", "english": "father; dad", "partOfSpeech": "noun",
        "exampleCn": "我爸爸是医生。", "examplePinyin": "Wǒ bàba shì yīshēng.", "exampleEn": "My dad is a doctor."
    },
    {
        "id": 1004, "level": 1, "hanzi": "北京", "pinyin": "Běijīng", "english": "Beijing (capital of China)", "partOfSpeech": "proper noun",
        "exampleCn": "我想去北京旅游。", "examplePinyin": "Wǒ xiǎng qù Běijīng lǚyóu.", "exampleEn": "I want to travel to Beijing."
    },
    {
        "id": 1005, "level": 1, "hanzi": "杯子", "pinyin": "bēizi", "english": "cup; glass", "partOfSpeech": "noun",
        "exampleCn": "桌子上有一个杯子。", "examplePinyin": "Zhuōzi shàng yǒu yí ge bēizi.", "exampleEn": "There is a cup on the table."
    },
    {
        "id": 1006, "level": 1, "hanzi": "本", "pinyin": "běn", "english": "measure word for books", "partOfSpeech": "measure word",
        "exampleCn": "这是一本中文书。", "examplePinyin": "Zhè shì yì běn Zhōngwén shū.", "exampleEn": "This is a Chinese book."
    },
    {
        "id": 1007, "level": 1, "hanzi": "不客气", "pinyin": "bú kèqi", "english": "you're welcome; don't mention it", "partOfSpeech": "phrase",
        "exampleCn": "谢谢你！——不客气。", "examplePinyin": "Xièxie nǐ! —— Bú kèqi.", "exampleEn": "Thank you! — You are welcome."
    },
    {
        "id": 1008, "level": 1, "hanzi": "不", "pinyin": "bù", "english": "not; no", "partOfSpeech": "adverb",
        "exampleCn": "我不是老师，我是学生。", "examplePinyin": "Wǒ bú shì lǎoshī, wǒ shì xuésheng.", "exampleEn": "I am not a teacher, I am a student."
    },
    {
        "id": 1009, "level": 1, "hanzi": "菜", "pinyin": "cài", "english": "dish (food); vegetable", "partOfSpeech": "noun",
        "exampleCn": "中国菜很好吃。", "examplePinyin": "Zhōngguó cài hěn hǎochī.", "exampleEn": "Chinese food is very delicious."
    },
    {
        "id": 1010, "level": 1, "hanzi": "茶", "pinyin": "chá", "english": "tea", "partOfSpeech": "noun",
        "exampleCn": "你喝茶还是喝水？", "examplePinyin": "Nǐ hē chá háishì hē shuǐ?", "exampleEn": "Do you drink tea or water?"
    },
    {
        "id": 1011, "level": 1, "hanzi": "吃", "pinyin": "chī", "english": "to eat", "partOfSpeech": "verb",
        "exampleCn": "我们去吃午饭吧。", "examplePinyin": "Wǒmen qù chī wǔfàn ba.", "exampleEn": "Let's go eat lunch."
    },
    {
        "id": 1012, "level": 1, "hanzi": "出租车", "pinyin": "chūzūchē", "english": "taxi; cab", "partOfSpeech": "noun",
        "exampleCn": "我们坐出租车去火车站。", "examplePinyin": "Wǒmen zuò chūzūchē qù huǒchēzhàn.", "exampleEn": "We go to the train station by taxi."
    },
    {
        "id": 1013, "level": 1, "hanzi": "打电话", "pinyin": "dǎ diànhuà", "english": "to make a phone call", "partOfSpeech": "verb phrase",
        "exampleCn": "他在给朋友打电话。", "examplePinyin": "Tā zài gěi péngyou dǎ diànhuà.", "exampleEn": "He is making a phone call to a friend."
    },
    {
        "id": 1014, "level": 1, "hanzi": "大", "pinyin": "dà", "english": "big; large", "partOfSpeech": "adjective",
        "exampleCn": "这个苹果很大。", "examplePinyin": "Zhè ge píngguǒ hěn dà.", "exampleEn": "This apple is very big."
    },
    {
        "id": 1015, "level": 1, "hanzi": "的", "pinyin": "de", "english": "possessive particle (indicates possession)", "partOfSpeech": "particle",
        "exampleCn": "这是我的手机。", "examplePinyin": "Zhè shì wǒ de shǒujī.", "exampleEn": "This is my mobile phone."
    },
    {
        "id": 1016, "level": 1, "hanzi": "点", "pinyin": "diǎn", "english": "o'clock; dot; point", "partOfSpeech": "noun",
        "exampleCn": "现在是早上八点。", "examplePinyin": "Xiànzài shì zǎoshang bā diǎn.", "exampleEn": "It is now eight o'clock in the morning."
    },
    {
        "id": 1017, "level": 1, "hanzi": "电脑", "pinyin": "diànnǎo", "english": "computer", "partOfSpeech": "noun",
        "exampleCn": "我买了一台新电脑。", "examplePinyin": "Wǒ mǎi le yì tái xīn diànnǎo.", "exampleEn": "I bought a new computer."
    },
    {
        "id": 1018, "level": 1, "hanzi": "电视", "pinyin": "diànshì", "english": "television; TV", "partOfSpeech": "noun",
        "exampleCn": "爸爸喜欢看电视。", "examplePinyin": "Bàba xǐhuan kàn diànshì.", "exampleEn": "Dad likes watching TV."
    },
    {
        "id": 1019, "level": 1, "hanzi": "电影", "pinyin": "diànyǐng", "english": "movie; film", "partOfSpeech": "noun",
        "exampleCn": "今晚我们去看电影吧。", "examplePinyin": "Jīnwǎn wǒmen qù kàn diànyǐng ba.", "exampleEn": "Let's go watch a movie tonight."
    },
    {
        "id": 1020, "level": 1, "hanzi": "东西", "pinyin": "dōngxi", "english": "thing; stuff", "partOfSpeech": "noun",
        "exampleCn": "我想去商店买东西。", "examplePinyin": "Wǒ xiǎng qù shāngdiàn mǎi dōngxi.", "exampleEn": "I want to go to the store to buy things."
    },
    {
        "id": 1021, "level": 1, "hanzi": "都", "pinyin": "dōu", "english": "all; both", "partOfSpeech": "adverb",
        "exampleCn": "我们都是学生。", "examplePinyin": "Wǒmen dōu shì xuésheng.", "exampleEn": "We are all students."
    },
    {
        "id": 1022, "level": 1, "hanzi": "读", "pinyin": "dú", "english": "to read aloud; to study", "partOfSpeech": "verb",
        "exampleCn": "请跟我读这个词。", "examplePinyin": "Qǐng gēn wǒ dú zhè ge cí.", "exampleEn": "Please read this word aloud with me."
    },
    {
        "id": 1023, "level": 1, "hanzi": "对不起", "pinyin": "duìbuqǐ", "english": "I'm sorry; excuse me", "partOfSpeech": "phrase",
        "exampleCn": "对不起，我迟到了。", "examplePinyin": "Duìbuqǐ, wǒ chídào le.", "exampleEn": "I am sorry, I am late."
    },
    {
        "id": 1024, "level": 1, "hanzi": "多", "pinyin": "duō", "english": "many; much; how (in questions)", "partOfSpeech": "adjective/adverb",
        "exampleCn": "这里人很多。", "examplePinyin": "Zhèlǐ rén hěn duō.", "exampleEn": "There are many people here."
    },
    {
        "id": 1025, "level": 1, "hanzi": "多少", "pinyin": "duōshao", "english": "how much; how many", "partOfSpeech": "pronoun",
        "exampleCn": "这个杯子多少钱？", "examplePinyin": "Zhè ge bēizi duōshao qián?", "exampleEn": "How much does this cup cost?"
    },
    {
        "id": 1026, "level": 1, "hanzi": "儿子", "pinyin": "érzi", "english": "son", "partOfSpeech": "noun",
        "exampleCn": "他有一个儿子和一个女儿。", "examplePinyin": "Tā yǒu yí ge érzi hé yí ge nǚ'ér.", "exampleEn": "He has a son and a daughter."
    },
    {
        "id": 1027, "level": 1, "hanzi": "二", "pinyin": "èr", "english": "two", "partOfSpeech": "numeral",
        "exampleCn": "现在是两点二十分。", "examplePinyin": "Xiànzài shì liǎng diǎn èrshí fēn.", "exampleEn": "It is now 2:20."
    },
    {
        "id": 1028, "level": 1, "hanzi": "饭店", "pinyin": "fàndiàn", "english": "restaurant; hotel", "partOfSpeech": "noun",
        "exampleCn": "这家饭店的菜很好吃。", "examplePinyin": "Zhè jiā fàndiàn de cài hěn hǎochī.", "exampleEn": "The dishes at this restaurant are delicious."
    },
    {
        "id": 1029, "level": 1, "hanzi": "飞机", "pinyin": "fēijī", "english": "airplane", "partOfSpeech": "noun",
        "exampleCn": "我明天坐飞机去上海。", "examplePinyin": "Wǒ míngtiān zuò fēijī qù Shànghǎi.", "exampleEn": "I will take an airplane to Shanghai tomorrow."
    },
    {
        "id": 1030, "level": 1, "hanzi": "分钟", "pinyin": "fēnzhōng", "english": "minute", "partOfSpeech": "noun",
        "exampleCn": "请等我十分钟。", "examplePinyin": "Qǐng děng wǒ shí fēnzhōng.", "exampleEn": "Please wait for me for ten minutes."
    },
    {
        "id": 1031, "level": 1, "hanzi": "高兴", "pinyin": "gāoxìng", "english": "happy; glad", "partOfSpeech": "adjective",
        "exampleCn": "认识你很高兴。", "examplePinyin": "Rènshi nǐ hěn gāoxìng.", "exampleEn": "Glad to meet you."
    },
    {
        "id": 1032, "level": 1, "hanzi": "个", "pinyin": "gè", "english": "general measure word", "partOfSpeech": "measure word",
        "exampleCn": "我有一个好朋友。", "examplePinyin": "Wǒ yǒu yí ge hǎo péngyou.", "exampleEn": "I have a good friend."
    },
    {
        "id": 1033, "level": 1, "hanzi": "工作", "pinyin": "gōngzuò", "english": "job; work; to work", "partOfSpeech": "noun/verb",
        "exampleCn": "你喜欢你的工作吗？", "examplePinyin": "Nǐ xǐhuan nǐ de gōngzuò ma?", "exampleEn": "Do you like your job?"
    },
    {
        "id": 1034, "level": 1, "hanzi": "狗", "pinyin": "gǒu", "english": "dog", "partOfSpeech": "noun",
        "exampleCn": "我家有一只可爱的小狗。", "examplePinyin": "Wǒ jiā yǒu yì zhī kě'ài de xiǎogǒu.", "exampleEn": "My family has a cute little dog."
    },
    {
        "id": 1035, "level": 1, "hanzi": "汉语", "pinyin": "Hànyǔ", "english": "Chinese language (Mandarin)", "partOfSpeech": "noun",
        "exampleCn": "汉语不难学。", "examplePinyin": "Hànyǔ bù nán xué.", "exampleEn": "Chinese is not hard to learn."
    },
    {
        "id": 1036, "level": 1, "hanzi": "好", "pinyin": "hǎo", "english": "good; well; fine", "partOfSpeech": "adjective",
        "exampleCn": "今天天气很好。", "examplePinyin": "Jīntiān tiānqì hěn hǎo.", "exampleEn": "The weather is very good today."
    },
    {
        "id": 1037, "level": 1, "hanzi": "喝", "pinyin": "hē", "english": "to drink", "partOfSpeech": "verb",
        "exampleCn": "多喝水对身体好。", "examplePinyin": "Duō hē shuǐ duì shēntǐ hǎo.", "exampleEn": "Drinking more water is good for your health."
    },
    {
        "id": 1038, "level": 1, "hanzi": "和", "pinyin": "hé", "english": "and; with", "partOfSpeech": "conjunction",
        "exampleCn": "我和他是同学。", "examplePinyin": "Wǒ hé tā shì tóngxué.", "exampleEn": "He and I are classmates."
    },
    {
        "id": 1039, "level": 1, "hanzi": "很", "pinyin": "hěn", "english": "very; quite", "partOfSpeech": "adverb",
        "exampleCn": "他很高兴收到礼物。", "examplePinyin": "Tā hěn gāoxìng shōudào lǐwù.", "exampleEn": "He was very glad to receive the gift."
    },
    {
        "id": 1040, "level": 1, "hanzi": "后面", "pinyin": "hòumian", "english": "behind; back", "partOfSpeech": "noun",
        "exampleCn": "学校后面有一家书店。", "examplePinyin": "Xuéxiào hòumian yǒu yì jiā shūdiàn.", "exampleEn": "Behind the school there is a bookstore."
    },
    {
        "id": 1041, "level": 1, "hanzi": "回", "pinyin": "huí", "english": "to return; to go back", "partOfSpeech": "verb",
        "exampleCn": "我想回家休息。", "examplePinyin": "Wǒ xiǎng huí jiā xiūxi.", "exampleEn": "I want to go back home and rest."
    },
    {
        "id": 1042, "level": 1, "hanzi": "会", "pinyin": "huì", "english": "can; to be able to; will", "partOfSpeech": "modal verb",
        "exampleCn": "你会说英语吗？", "examplePinyin": "Nǐ huì shuō Yīngyǔ ma?", "exampleEn": "Can you speak English?"
    },
    {
        "id": 1043, "level": 1, "hanzi": "几", "pinyin": "jǐ", "english": "how many; a few", "partOfSpeech": "pronoun",
        "exampleCn": "你有几本书？", "examplePinyin": "Nǐ yǒu jǐ běn shū?", "exampleEn": "How many books do you have?"
    },
    {
        "id": 1044, "level": 1, "hanzi": "家", "pinyin": "jiā", "english": "family; home", "partOfSpeech": "noun",
        "exampleCn": "欢迎来我家做客。", "examplePinyin": "Huānyíng lái wǒ jiā zuòkè.", "exampleEn": "Welcome to come as a guest to my house."
    },
    {
        "id": 1045, "level": 1, "hanzi": "叫", "pinyin": "jiào", "english": "to be called; to call", "partOfSpeech": "verb",
        "exampleCn": "你叫什么名字？", "examplePinyin": "Nǐ jiào shénme míngzi?", "exampleEn": "What is your name?"
    },
    {
        "id": 1046, "level": 1, "hanzi": "今天", "pinyin": "jīntiān", "english": "today", "partOfSpeech": "noun",
        "exampleCn": "今天星期五。", "examplePinyin": "Jīntiān xīngqīwǔ.", "exampleEn": "Today is Friday."
    },
    {
        "id": 1047, "level": 1, "hanzi": "九", "pinyin": "jiǔ", "english": "nine", "partOfSpeech": "numeral",
        "exampleCn": "教室里有九个学生。", "examplePinyin": "Jiàoshì lǐ yǒu jiǔ ge xuésheng.", "exampleEn": "There are nine students in the classroom."
    },
    {
        "id": 1048, "level": 1, "hanzi": "开", "pinyin": "kāi", "english": "to drive; to open", "partOfSpeech": "verb",
        "exampleCn": "他正在开车。", "examplePinyin": "Tā zhèngzài kāichē.", "exampleEn": "He is driving a car."
    },
    {
        "id": 1049, "level": 1, "hanzi": "看", "pinyin": "kàn", "english": "to see; to look; to read", "partOfSpeech": "verb",
        "exampleCn": "你在看什么书？", "examplePinyin": "Nǐ zài kàn shénme shū?", "exampleEn": "What book are you reading?"
    },
    {
        "id": 1050, "level": 1, "hanzi": "看见", "pinyin": "kànjiàn", "english": "to see; to catch sight of", "partOfSpeech": "verb",
        "exampleCn": "我看见他在图书馆。", "examplePinyin": "Wǒ kànjiàn tā zài túshūguǎn.", "exampleEn": "I saw him in the library."
    },

    # --- HSK 2 Samples ---
    {
        "id": 2001, "level": 2, "hanzi": "吧", "pinyin": "ba", "english": "suggestion particle (how about...)", "partOfSpeech": "particle",
        "exampleCn": "我们一起走吧。", "examplePinyin": "Wǒmen yìqǐ zǒu ba.", "exampleEn": "Let's walk together."
    },
    {
        "id": 2002, "level": 2, "hanzi": "白", "pinyin": "bái", "english": "white; blank", "partOfSpeech": "adjective",
        "exampleCn": "她穿着一件白色的衬衫。", "examplePinyin": "Tā chuān zhe yí jiàn báisè de chènshān.", "exampleEn": "She is wearing a white shirt."
    },
    {
        "id": 2003, "level": 2, "hanzi": "百", "pinyin": "bǎi", "english": "hundred", "partOfSpeech": "numeral",
        "exampleCn": "这本书有一百页。", "examplePinyin": "Zhè běn shū yǒu yì bǎi yè.", "exampleEn": "This book has one hundred pages."
    },
    {
        "id": 2004, "level": 2, "hanzi": "帮助", "pinyin": "bāngzhù", "english": "to help; assistance", "partOfSpeech": "verb/noun",
        "exampleCn": "谢谢你的帮助。", "examplePinyin": "Xièxie nǐ de bāngzhù.", "exampleEn": "Thank you for your help."
    },
    {
        "id": 2005, "level": 2, "hanzi": "报纸", "pinyin": "bàozhǐ", "english": "newspaper", "partOfSpeech": "noun",
        "exampleCn": "爷爷喜欢在早上看报纸。", "examplePinyin": "Yéye xǐhuan zài zǎoshang kàn bàozhǐ.", "exampleEn": "Grandpa likes reading the newspaper in the morning."
    },
    {
        "id": 2006, "level": 2, "hanzi": "比", "pinyin": "bǐ", "english": "to compare; than", "partOfSpeech": "preposition",
        "exampleCn": "今天比昨天冷。", "examplePinyin": "Jīntiān bǐ zuótiān lěng.", "exampleEn": "Today is colder than yesterday."
    },
    {
        "id": 2007, "level": 2, "hanzi": "别", "pinyin": "bié", "english": "don't; other", "partOfSpeech": "adverb",
        "exampleCn": "别担心，一切都会好的。", "examplePinyin": "Bié dānxīn, yíqiè dōu huì hǎo de.", "exampleEn": "Don't worry, everything will be fine."
    },
    {
        "id": 2008, "level": 2, "hanzi": "长", "pinyin": "cháng", "english": "long (length or time)", "partOfSpeech": "adjective",
        "exampleCn": "这条路很长。", "examplePinyin": "Zhè tiáo lù hěn cháng.", "exampleEn": "This road is very long."
    },
    {
        "id": 2009, "level": 2, "hanzi": "唱歌", "pinyin": "chànggē", "english": "to sing a song", "partOfSpeech": "verb phrase",
        "exampleCn": "妹妹很喜欢唱歌。", "examplePinyin": "Mèimei hěn xǐhuan chànggē.", "exampleEn": "My younger sister really likes singing."
    },
    {
        "id": 2010, "level": 2, "hanzi": "穿", "pinyin": "chuān", "english": "to wear; to put on", "partOfSpeech": "verb",
        "exampleCn": "天气冷了，多穿件衣服。", "examplePinyin": "Tiānqì lěng le, duō chuān jiàn yīfu.", "exampleEn": "The weather has gotten cold, put on more clothes."
    },

    # --- HSK 3 Samples ---
    {
        "id": 3001, "level": 3, "hanzi": "阿姨", "pinyin": "āyí", "english": "aunt; maternal aunt; nanny", "partOfSpeech": "noun",
        "exampleCn": "阿姨送了我一份礼物。", "examplePinyin": "Āyí sòng le wǒ yí fèn lǐwù.", "exampleEn": "Aunt gave me a present."
    },
    {
        "id": 3002, "level": 3, "hanzi": "矮", "pinyin": "ǎi", "english": "short; low", "partOfSpeech": "adjective",
        "exampleCn": "弟弟比哥哥矮一点。", "examplePinyin": "Dìdi bǐ gēge ǎi yìdiǎn.", "exampleEn": "The younger brother is a bit shorter than the elder brother."
    },
    {
        "id": 3003, "level": 3, "hanzi": "安静", "pinyin": "ānjìng", "english": "quiet; peaceful", "partOfSpeech": "adjective",
        "exampleCn": "图书馆里请保持安静。", "examplePinyin": "Túshūguǎn lǐ qǐng bǎochí ānjìng.", "exampleEn": "Please keep quiet in the library."
    },
    {
        "id": 3004, "level": 3, "hanzi": "把", "pinyin": "bǎ", "english": "particle indicating object handling; hold", "partOfSpeech": "preposition",
        "exampleCn": "请把门关上。", "examplePinyin": "Qǐng bǎ mén guān shàng.", "exampleEn": "Please close the door."
    },
    {
        "id": 3005, "level": 3, "hanzi": "搬", "pinyin": "bān", "english": "to move (objects or house)", "partOfSpeech": "verb",
        "exampleCn": "我们下个月要搬新家。", "examplePinyin": "Wǒmen xià ge yuè yào bān xīn jiā.", "exampleEn": "We are going to move into a new house next month."
    },

    # --- HSK 4 Samples ---
    {
        "id": 4001, "level": 4, "hanzi": "爱情", "pinyin": "àiqíng", "english": "romantic love; love romance", "partOfSpeech": "noun",
        "exampleCn": "这是一个感人的爱情故事。", "examplePinyin": "Zhè shì yí ge gǎnrén de àiqíng gùshi.", "exampleEn": "This is a touching love story."
    },
    {
        "id": 4002, "level": 4, "hanzi": "安排", "pinyin": "ānpái", "english": "to arrange; arrangement", "partOfSpeech": "verb/noun",
        "exampleCn": "经理安排了明天的会议。", "examplePinyin": "Jīnglǐ ānpái le míngtiān de huìyì.", "exampleEn": "The manager arranged tomorrow's meeting."
    },
    {
        "id": 4003, "level": 4, "hanzi": "安全", "pinyin": "ānquán", "english": "safe; secure; safety", "partOfSpeech": "adjective/noun",
        "exampleCn": "出门在外，安全第一。", "examplePinyin": "Chūmén zàiwài, ānquán dì-yī.", "exampleEn": "When traveling away, safety comes first."
    },
    {
        "id": 4004, "level": 4, "hanzi": "按时", "pinyin": "ànshí", "english": "on time; on schedule", "partOfSpeech": "adverb",
        "exampleCn": "请按时完成工作。", "examplePinyin": "Qǐng ànshí wánchéng gōngzuò.", "exampleEn": "Please complete the work on schedule."
    },

    # --- HSK 5 Samples ---
    {
        "id": 5001, "level": 5, "hanzi": "哎", "pinyin": "āi", "english": "interjection of surprise or sigh", "partOfSpeech": "interjection",
        "exampleCn": "哎，你怎么现在才来？", "examplePinyin": "Āi, nǐ zěnme xiànzài cái lái?", "exampleEn": "Hey, why did you only arrive now?"
    },
    {
        "id": 5002, "level": 5, "hanzi": "唉", "pinyin": "ài", "english": "alas (sighing sound)", "partOfSpeech": "interjection",
        "exampleCn": "唉，真可惜！", "examplePinyin": "Ài, zhēn kěxī!", "exampleEn": "Alas, what a pity!"
    },
    {
        "id": 5003, "level": 5, "hanzi": "爱护", "pinyin": "àihù", "english": "to cherish; to take good care of", "partOfSpeech": "verb",
        "exampleCn": "我们应该爱护公共设施。", "examplePinyin": "Wǒmen yīnggāi àihù gōnggòng shèshī.", "exampleEn": "We should take good care of public facilities."
    },
    {
        "id": 5004, "level": 5, "hanzi": "爱惜", "pinyin": "àixī", "english": "to treasure; to use sparingly", "partOfSpeech": "verb",
        "exampleCn": "我们要爱惜粮食。", "examplePinyin": "Wǒmen yào àixī liángshí.", "exampleEn": "We must treasure and not waste grain."
    }
]

print(f"Total initial words: {len(hsk_data)}")
